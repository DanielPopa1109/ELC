/* USER CODE BEGIN Header */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "SMon.h"
#include "Dcm.h"
#include "EcuM.h"
#include "CanH.h"
#include "adc.h"
#include "tim.h"
#include "Dem.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
static TaskStatus_t xTaskStatusArray[7];
static UBaseType_t uxArraySize;
uint8_t OS_IdleIndex = 0u;
uint8_t OS_XCP_U8_CPU_Load = 0u;
volatile uint32_t oscnt = 0u;
uint32_t ulTotalRunTime_G = 0u;
uint32_t localTaskCounter = 0u;
float OS_XCP_CpuLoad = 0.0f;
float OS_IdleRunTime = 0.0f;
float OS_DeltaIdleRunTime = 0.0f;
float OS_CpuLoad  = 0.0f;
float OS_AverageCpuLoad  = 0.0f;
volatile unsigned long ulHighFrequencyTimerTicks = 0u;
long long idlecnt = 0u;
long long OS_Counter = 0u;
long long IDLE_Counter = 0u;
/* USER CODE END Variables */
/* Definitions for QM_BSW */
osThreadId_t QM_BSWHandle;
const osThreadAttr_t QM_BSW_attributes = {
  .name = "QM_BSW",
  .stack_size = 272 * 4,
  .priority = (osPriority_t) osPriorityHigh5,
};
/* Definitions for QM_APPL */
osThreadId_t QM_APPLHandle;
const osThreadAttr_t QM_APPL_attributes = {
  .name = "QM_APPL",
  .stack_size = 272 * 4,
  .priority = (osPriority_t) osPriorityHigh4,
};
/* Definitions for QM_DIAG */
osThreadId_t QM_DIAGHandle;
const osThreadAttr_t QM_DIAG_attributes = {
  .name = "QM_DIAG",
  .stack_size = 872 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for CPULOAD_OS */
osThreadId_t CPULOAD_OSHandle;
const osThreadAttr_t CPULOAD_OS_attributes = {
  .name = "CPULOAD_OS",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for Alarm5ms */
osTimerId_t Alarm5msHandle;
const osTimerAttr_t Alarm5ms_attributes = {
  .name = "Alarm5ms"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
/* USER CODE END FunctionPrototypes */

void QM_BSW_TASK(void *argument);
void QM_APPL_TASK(void *argument);
void QM_DIAG_TASK(void *argument);
void CPULOAD_OS_TASK(void *argument);
void Alarm5ms_Callback(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);
void vApplicationIdleHook(void);
void vApplicationTickHook(void);
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName);
void vApplicationMallocFailedHook(void);

/* USER CODE BEGIN 1 */

void configureTimerForRunTimeStats(void)
{
	ulHighFrequencyTimerTicks = 0;
	HAL_TIM_Base_Start_IT(&htim3);
}

unsigned long getRunTimeCounterValue(void)
{
	return ulHighFrequencyTimerTicks;
}

/* USER CODE END 1 */

/* USER CODE BEGIN 2 */

void vApplicationIdleHook( void )
{
	idlecnt++;
	uxArraySize = uxTaskGetSystemState(xTaskStatusArray, 7, &ulTotalRunTime_G);
}

/* USER CODE END 2 */

/* USER CODE BEGIN 3 */
void vApplicationTickHook( void )
{
	oscnt++;

	if (EcuM_SWState < 3)
	{
		uint32_t adcState = HAL_ADC_GetState(&hadc1);

		if ((adcState & HAL_ADC_STATE_REG_BUSY) == 0u)
		{
			if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)Ain_DmaBuffer, 5u) != HAL_OK)
			{
				/* do nothing */
			}
		}
		else
		{
			/* do nothing */
		}
	}
	else
	{
		/* do nothing */
	}
}

/* USER CODE END 3 */

/* USER CODE BEGIN 4 */

void vApplicationStackOverflowHook(TaskHandle_t xTask, signed char *pcTaskName)
{
	EcuM_PerformReset(203, 203);
}

/* USER CODE END 4 */

/* USER CODE BEGIN 5 */

void vApplicationMallocFailedHook(void)
{
	EcuM_PerformReset(204, 204);
}

/* USER CODE END 5 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of Alarm5ms */
  Alarm5msHandle = osTimerNew(Alarm5ms_Callback, osTimerPeriodic, NULL, &Alarm5ms_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of QM_BSW */
  QM_BSWHandle = osThreadNew(QM_BSW_TASK, NULL, &QM_BSW_attributes);

  /* creation of QM_APPL */
  QM_APPLHandle = osThreadNew(QM_APPL_TASK, NULL, &QM_APPL_attributes);

  /* creation of QM_DIAG */
  QM_DIAGHandle = osThreadNew(QM_DIAG_TASK, NULL, &QM_DIAG_attributes);

  /* creation of CPULOAD_OS */
  CPULOAD_OSHandle = osThreadNew(CPULOAD_OS_TASK, NULL, &CPULOAD_OS_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
	osTimerStart(Alarm5msHandle, 5);
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_QM_BSW_TASK */
/* USER CODE END Header_QM_BSW_TASK */
void QM_BSW_TASK(void *argument)
{
  /* USER CODE BEGIN QM_BSW_TASK */
	/* Infinite loop */
	for(;;)
	{
		EcuM_main();
		Dem_main();
		CanH_MainFunction();
		vTaskSuspend(NULL);
	}
  /* USER CODE END QM_BSW_TASK */
}

/* USER CODE BEGIN Header_QM_APPL_TASK */
/**
 * @brief Function implementing the QM_APPL thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_QM_APPL_TASK */
void QM_APPL_TASK(void *argument)
{
  /* USER CODE BEGIN QM_APPL_TASK */
	/* Infinite loop */
	for(;;)
	{
		SMon_main();
		vTaskSuspend(NULL);
	}
  /* USER CODE END QM_APPL_TASK */
}

/* USER CODE BEGIN Header_QM_DIAG_TASK */
/**
 * @brief Function implementing the QM_DIAG thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_QM_DIAG_TASK */
void QM_DIAG_TASK(void *argument)
{
  /* USER CODE BEGIN QM_DIAG_TASK */
	/* Infinite loop */
	for(;;)
	{
		Dcm_main();
		vTaskSuspend(NULL);
	}
  /* USER CODE END QM_DIAG_TASK */
}

/* USER CODE BEGIN Header_CPULOAD_OS_TASK */
/* USER CODE END Header_CPULOAD_OS_TASK */
void CPULOAD_OS_TASK(void *argument)
{
  /* USER CODE BEGIN CPULOAD_OS_TASK */
	for(;;)
	{
		localTaskCounter++;

		OS_DeltaIdleRunTime = xTaskStatusArray[OS_IdleIndex].ulRunTimeCounter - OS_IdleRunTime;

		if (ulHighFrequencyTimerTicks != 0u)
		{
			uint32_t idle_permille = (OS_DeltaIdleRunTime * 1000u) / ulHighFrequencyTimerTicks;

			if (idle_permille > 1000u)
			{
				idle_permille = 1000u;
			}
			else
			{
				/* Do nothing. */
			}

			OS_CpuLoad = 100u - (idle_permille / 10u);
		}
		else
		{
			/* Do nothing. */
		}

		OS_AverageCpuLoad += OS_CpuLoad;
		ulHighFrequencyTimerTicks = 0u;
		OS_IdleRunTime = xTaskStatusArray[OS_IdleIndex].ulRunTimeCounter;

		if(localTaskCounter % 12u == 0u && 0u != localTaskCounter)
		{
			OS_XCP_CpuLoad = OS_AverageCpuLoad / 12; /* Calculate CPU load value every 480 milliseconds. */
			OS_XCP_U8_CPU_Load = (uint8_t)OS_XCP_CpuLoad;
			OS_AverageCpuLoad = 0u;
		}
		else
		{
			/* Do nothing. */
		}

		vTaskSuspend(NULL);
	}
  /* USER CODE END CPULOAD_OS_TASK */
}

/* Alarm5ms_Callback function */
void Alarm5ms_Callback(void *argument)
{
  /* USER CODE BEGIN Alarm5ms_Callback */

	static uint32_t counter = 0u;

	counter++;

	if(counter % 8u == 0u && counter != 0u)
	{
		vTaskResume(CPULOAD_OSHandle);
	}
	else
	{
		/* Do nothing. */
	}

	vTaskResume(QM_APPLHandle);
	vTaskResume(QM_BSWHandle);
	vTaskResume(QM_DIAGHandle);

  /* USER CODE END Alarm5ms_Callback */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
/* USER CODE END Application */

