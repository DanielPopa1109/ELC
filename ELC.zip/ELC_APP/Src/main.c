/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
#include "can.h"
#include "crc.h"
#include "dma.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include "Nvm.h"
#include "SMon.h"
#include "EcuM.h"
#include "Dcm.h"
#include "../BSW/Com/PduR/PduR.h"
#include "../BSW/Com/CanIf/CanIf.h"
#include "../BSW/Com/Com/Com.h"
#include "../BSW/Com/CanNm/CanNm.h"
#include "../BSW/Com/CanSM/CanSM.h"
#include "../BSW/Com/ComM/ComM.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint16_t Ain_DmaBuffer[5u];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
static void MX_NVIC_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	static float v1 = 0.0f;
	static float v4 = 0.0f;
	static float v5 = 0.0f;
	static float aux_isense = 0.0f;
	static float vfb1_mV = 0.0f;
	static float vfb2_mV = 0.0f;
	static float ln_ratio = 0.0f;
	static float inv_T = 0.0f;
	static float T_kelvin = 0.0f;
	static float aux_isense2 = 0.0f;
	static float filt_isense2 = 0.0f;
	static float aux_mcutemp = 0.0f;
	static float aux_ntctemp = 0.0f;
	const float ADC_MAX = (float)SMon_P_ADC_MaxValue;
	const float VREF = SMon_P_Varef;
	const float EPS = 1e-3f;

	float adc1 = ((float)Ain_DmaBuffer[1u] / ADC_MAX) * VREF;
	float adc3 = ((float)Ain_DmaBuffer[3u] / ADC_MAX) * 3.3f;
	float adc4 = ((float)Ain_DmaBuffer[4u] / ADC_MAX) * VREF;

	if (adc3 >= (5.0f - EPS))
	{
		adc3 = 5.0f - EPS;
	}
	else if (adc3 < 0.0f)
	{
		adc3 = 0.0f;
	}
	else
	{
		/* Do nothing. */
	}

	v1 = adc1;
	v5 = adc4;

	float denom = (5.0f - adc3);

	bool ntc_valid = false;
	ln_ratio = 0.0f;   /* deterministic reset every cycle */

	if (denom > EPS)
	{
		v4 = SMon_P_NTC_PullUp_ResistorVale * adc3 / denom;

		if (v4 > EPS)
		{
			ln_ratio = logf(v4 / (float)SMon_P_NTC_L1_TwoPointCalibration_ParamA);
			ntc_valid = true;
		}
		else
		{
			ntc_valid = false;
		}
	}
	else
	{
		v4 = 0.0f;
		ntc_valid = false;
	}

	if (ntc_valid == true)
	{
		inv_T = (1.0f / SMon_P_RoomTempKelvin) +
				(ln_ratio / (float)SMon_P_NTC_L1_TwoPointCalibration_ParamB);

		if (inv_T > EPS)
		{
			T_kelvin = 1.0f / inv_T;
		}
		else
		{
			T_kelvin = SMon_P_RoomTempKelvin;
		}
	}
	else
	{
		T_kelvin = SMon_P_RoomTempKelvin;
	}

	vfb1_mV = SMon_P_VFB_L1_TwoPointCalibration_ParamA * Ain_DmaBuffer[2u] +
			SMon_P_VFB_L1_TwoPointCalibration_ParamB;
	vfb2_mV = SMon_P_VFB_T30_TwoPointCalibration_ParamA * Ain_DmaBuffer[0u] +
			SMon_P_VFB_T30_TwoPointCalibration_ParamB;
	aux_isense = (v1 - SMon_P_TwoPointCalib_NoLoad_ISense) *
			SMon_P_TwoPointCalib_ConvFacISense;
	aux_isense2 = aux_isense;
	filt_isense2 = filt_isense2 +
			SMon_P_AlphaFilterExtChIsense * (aux_isense2 - filt_isense2);

	if (SMon_PeakCurrent < abs(aux_isense))
	{
		SMon_PeakCurrent = aux_isense;
	}
	else
	{
		/* Do nothing. */
	}

	SMon_ISenseL1_ExtChISense = filt_isense2 / 1000.0f;
	SMon_ISenseL1_Float = aux_isense / 1000.0f;
	SMon_ISenseL1 = aux_isense;
	SMon_VfbL1 = vfb1_mV;
	SMon_VfbT30 = vfb2_mV;
	aux_mcutemp = ((SMon_P_VoltsAt25 - v5) / SMon_P_AvgSlope) +
			SMon_P_RoomTemperature;
	aux_ntctemp = T_kelvin - SMon_P_Kelvin;
	SMon_NTC_Temperature_L1 =
			SMon_NTC_Temperature_L1 +
			SMon_P_AlphaFilter *
			(aux_ntctemp - SMon_NTC_Temperature_L1);
	SMon_McuTempValue =
			SMon_McuTempValue +
			SMon_P_AlphaFilter *
			(aux_mcutemp - SMon_McuTempValue);
}

void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
	if(0u != hadc->ErrorCode)
	{
		SMon_ISenseL1 = 0xFFFFu;
		SMon_VfbL1 = 0xFFFFu;
		SMon_VfbT30 = 0xFFFFu;
		SMon_NTC_Temperature_L1 = 1e9f;
		SMon_McuTempValue = 1e9f;
		EcuM_PerformReset(125u, 125u);
	}
	else
	{
		/* Do nothing. */
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

	PWR_PVDTypeDef sConfigPVD;

	sConfigPVD.Mode = PWR_PVD_MODE_IT_FALLING;
	sConfigPVD.PVDLevel = PWR_PVDLEVEL_0;

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_CAN_Init();
  MX_CRC_Init();
  MX_TIM3_Init();
	PduR_Init();
	CanIf_Init();
	Com_Init();
	CanNm_Init();
	CanSM_Init();
	ComM_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);

	htim1.Instance->CCR1 = 0;

	HAL_PWR_ConfigPVD(&sConfigPVD);

	HAL_PWR_EnablePVD();

	HAL_ADC_Stop(&hadc1);

	HAL_ADCEx_Calibration_Start(&hadc1);

	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)Ain_DmaBuffer, 5u);

	for(uint8_t i = 0u; i < 4u; i++)
	{
		if(EcuM_SWV[i] != Dcm_SWV[i])
		{
			for(uint32_t* addr = ((uint32_t*)0x20004fc0); addr <= ((uint32_t*)0x20004fff); addr++)
			{
				*addr = 0;
			}

			break;
		}
		else
		{
			/* Do nothing. */
		}
	}

	Nvm_ReadAll();
	Nvm_InitParamFlash();

	__enable_irq();
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* Call init function for freertos objects (in cmsis_os2.c) */
  MX_FREERTOS_Init();

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* USB_HP_CAN1_TX_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(USB_HP_CAN1_TX_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(USB_HP_CAN1_TX_IRQn);
  /* USB_LP_CAN1_RX0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(USB_LP_CAN1_RX0_IRQn, 8, 0);
  HAL_NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
  /* CAN1_RX1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(CAN1_RX1_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(CAN1_RX1_IRQn);
  /* CAN1_SCE_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(CAN1_SCE_IRQn, 11, 0);
  HAL_NVIC_EnableIRQ(CAN1_SCE_IRQn);
  /* RCC_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(RCC_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(RCC_IRQn);
  /* FLASH_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(FLASH_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(FLASH_IRQn);
  /* PVD_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(PVD_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(PVD_IRQn);
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 10, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* TIM1_CC_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_CC_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(TIM1_CC_IRQn);
  /* TIM1_TRG_COM_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_TRG_COM_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(TIM1_TRG_COM_IRQn);
  /* TIM1_UP_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_UP_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(TIM1_UP_IRQn);
  /* TIM1_BRK_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_BRK_IRQn, 15, 0);
  HAL_NVIC_EnableIRQ(TIM1_BRK_IRQn);
  /* ADC1_2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(ADC1_2_IRQn, 9, 0);
  HAL_NVIC_EnableIRQ(ADC1_2_IRQn);
  /* TIM3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(TIM3_IRQn);
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */
  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	EcuM_PerformReset(196, 196);
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
