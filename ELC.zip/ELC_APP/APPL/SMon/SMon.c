#include "SMon.h"
#include "CanH.h"
#include "Dem.h"
#include "Nvm.h"
#include "Dcm.h"
#include "EcuM.h"

uint8_t SMon_NtcError = 0u;
uint8_t SMon_ExternalChargerDetected = 0u;
uint8_t SMon_RequestPhysicalStatus = 0xFF;
uint8_t SMon_CLSFlag = 0u; // CLS status flag - not started / running / done
uint8_t SMon_S2BErrorStatus = 0u;
uint8_t SMon_I2TError = 0u;
uint8_t SMon_L1_UVStatus = 0u;
uint8_t SMon_CLS_Failure = 0u;
uint8_t SMon_ECU_UV = 0u;
uint8_t SMon_ECU_OV = 0u;
uint8_t SMon_SWState = 0u; // EcuM SW state
uint8_t SMon_ShortToPlusTest = 0u; // Discharge Test Status
uint8_t SMon_CmdStat = 0xFF; // Command Status
uint8_t SMon_CalculatedCommand = 0xFF;
uint8_t SMon_L1ST; // L1 Status
uint8_t SMon_RetryCnt; // Retry Counter
uint8_t SMon_LockSupply; // Lock Supply Output
uint16_t SMon_VfbL1 = 0xFFFFu; // Voltage Feedback L1/CLS
uint16_t SMon_VfbT30 = 0xFFFFu; // Voltage Feedback KL30
static uint16_t SMon_T30P50 = 0u; // 50% of KL30
static uint32_t SMon_MainCnt = 0u; // Main Counter
static uint32_t SMon_CounterUVL1 = 0u; // UV L1 Counter  For De-Bounce
static uint32_t SMon_CLSCheckVoltage_Timestamp;
uint32_t SMon_I2TCounter = 0u; // I2T Counter
uint32_t SMon_ISenseL1 = 0; // I Sense L1
float SMon_NTC_Temperature_L1;
float SMon_ISenseL1_Float;
float SMon_PeakCurrent;
float SMon_ISenseL1_ExtChISense;
float SMon_McuTempValue = 0.0f;
SMon_BatteryData_t SMon_Battery;
SMon_BatteryInternal_t SMon_BattInt;

uint32_t SMon_P_StatusVoltageL1Filter = 250u;
uint32_t SMon_P_I2TDebounceTime = 20u;
uint32_t SMon_P_Rtcntmax = 13u; // Retry Counter Parameter
uint32_t SMon_P_CLSTime = 22u; // CLS Duration Parameter
uint32_t SMon_P_WaitTimeOVUV = 80u; // OV UV De-bounce Time Parameter
uint32_t SMon_P_I2TDecrementPercentFactor = 85u; // Cooling Off Factor Parameter
uint32_t SMon_P_ClsFailureWaitTime = 190u; // Wait Time Between CLS Retries Parameter
uint32_t SMon_P_DischargeTimeCycles = 132000u; // ~50% Starting Voltage Discharge Time Parameter
uint32_t SMon_P_LowVoltage = 1200u; // 5TAU / Maximum Discharge Voltage Threshold Parameter
uint32_t SMon_P_UV_KL30 = 6900u; // UV KL30 TH Parameter
uint32_t SMon_P_OV_KL30 = 17200u; // OV KL30 TH Parameter
uint32_t SMon_P_UV_CLS = 700u;
uint32_t SMon_P_Varef = 3300u;
uint32_t SMon_P_ADC_MaxValue = 4095u;
uint32_t SMon_P_NTC_PullUp_ResistorVale = 91000u;
uint32_t SMon_P_LongDischargeTimeCycles = 564000u; // Maximum Discharge Time Parameter
uint32_t SMon_P_LowDisTimeCyc = 229600; // 2TAU Discharge Time Parameter
float SMon_P_VFB_T30_TwoPointCalibration_ParamA = 8.16f;
float SMon_P_VFB_T30_TwoPointCalibration_ParamB = 21.93f;
float SMon_P_VFB_L1_TwoPointCalibration_ParamA = 8.13f;
float SMon_P_VFB_L1_TwoPointCalibration_ParamB = 8.13f;
uint32_t SMon_P_NTC_L1_TwoPointCalibration_ParamA = 12332u; // R0_cal in ohms
uint32_t SMon_P_NTC_L1_TwoPointCalibration_ParamB = 4984u;  // Beta_cal in K
float SMon_P_ISenseNominal = 28.000f; // Nominal Current Parameter
float SMon_P_I2TRating = 1176.0f; // I2T Rating Parameter
float SMon_P_RoomTempKelvin = 297.15f;
float SMon_P_VoltsAt25 = 1430.0f;
float SMon_P_AvgSlope = 4.30f;
float SMon_P_RoomTemperature = 25.0f;
float SMon_P_Kelvin = 273.15f;
float SMon_P_AlphaFilter = 0.90f;
float SMon_P_AlphaFilterExtChIsense = 0.0001f;
float SMon_P_TwoPointCalib_ConvFacISense = 15.91f;
float SMon_P_TwoPointCalib_NoLoad_ISense = 613.2f;
float SMon_P_ExternalChargerThreshold = -1.0f;
float SMon_P_NTCTemperatureMax = 90.0f;
float SMon_P_NTCTemperatureRelease = 80.0f;
float SMon_P_BattNominalCapacity_Ah      = 77.0f;
float SMon_P_BattMinSoC_pct              = 1.0f;
float SMon_P_BattMaxSoC_pct              = 100.0f;
float SMon_P_BattRestVoltDelta_V         = 0.02f;
uint32_t SMon_P_BattRestTimeTicks        = 200u;   /* tune to scheduler tick */
float SMon_P_BattWeakVolt_V              = 11.80f;
float SMon_P_BattDeepDischargeVolt_V     = 11.10f;
float SMon_P_BattCrankVolt_V             = 9.60f;
float SMon_P_BattAlphaVolt               = 0.02f;
float SMon_P_BattAlphaCurr               = 0.05f;
float SMon_P_BattAlphaRint               = 0.10f;
float SMon_P_BattChargeEfficiency        = 0.90f;
float SMon_P_BattOcvCorrectionGain       = 0.20f;
float SMon_P_BattSoHMin_pct              = 1.0f;
float SMon_P_BattSoHMax_pct              = 100.0f;
float SMon_P_BattNominalRint_Ohm         = 0.015f;  /* typical healthy flooded/AGM range must be calibrated */
float SMon_P_BattBadRint_Ohm             = 0.060f;
float SMon_P_BattCurrentDeadband_A = 1.0f;
float SMon_P_BattCurrentHys_A            = 0.30f;
float SMon_P_BattChargePathDeltaOn_V     = 0.25f;
float SMon_P_BattChargePathDeltaOff_V    = 0.10f;
float SMon_P_BattRintMinStep_A           = 0.20f;
float SMon_P_BattRestDetectCurrent_A = 0.30f;

static void SMon_LoadCurrentErrorState(void);
static void SMon_LoadSwitchState(void);
static void SMon_ProcessShortToPlusTest(void);
static void SMon_ProcessLoadCurrentState(void);
static void SMon_I2TAccumulation(void);
static void SMon_ProcessEcuVoltageState(void);
static void SMon_ProcessLoadErrorStatus(void);
static void SMon_LoadSwitchingLogic(void);
static void SMon_LoadSwitchingDiagnosis(void);
static void SMon_BatteryData(void);
static float SMon_Batt_AbsF(float x);
static float SMon_Batt_ClampF(float x, float lo, float hi);
static float SMon_Batt_OcvToSoc(float ocv_v);
static float SMon_Batt_RintToSoh(float rint_ohm);
void SMon_main(void);

static void SMon_I2TAccumulation(void)
{
	static float I2TCounter_Float;
	static float ISenseL1_Average_Float;
	static float ISenseL1_Avged_Float;
	static float DeltaAmper_Float;
	static uint8_t localI2tAvgCounter = 0u;

	if(1u == SMon_CmdStat)
	{
		if(SMon_P_I2TDebounceTime > localI2tAvgCounter)
		{
			localI2tAvgCounter++;
			ISenseL1_Average_Float += SMon_ISenseL1_Float;
		}
		else
		{
			ISenseL1_Avged_Float = ISenseL1_Average_Float / localI2tAvgCounter;
			localI2tAvgCounter = 0u;
			ISenseL1_Average_Float = 0u;
		}
	}
	else
	{
		/* Do nothing. */
	}

	if(SMon_P_ISenseNominal < ISenseL1_Avged_Float && 0u == SMon_I2TError && 1u == SMon_CmdStat)
	{
		DeltaAmper_Float = (ISenseL1_Avged_Float * ISenseL1_Avged_Float - SMon_P_ISenseNominal * SMon_P_ISenseNominal) / 10.0f;
		I2TCounter_Float += DeltaAmper_Float;
		SMon_I2TCounter = (uint32_t)I2TCounter_Float;
	}
	else
	{
		if(SMon_MainCnt % SMon_P_I2TDebounceTime == 0u)
		{
			I2TCounter_Float = (I2TCounter_Float * SMon_P_I2TDecrementPercentFactor) / 100u;
			SMon_I2TCounter = (uint32_t)I2TCounter_Float;

			if(1u > I2TCounter_Float)
			{
				I2TCounter_Float = 0u;
				SMon_I2TCounter = (uint32_t)I2TCounter_Float;
			}
			else
			{
				/* Do nothing. */
			}
		}
		else
		{
			/* Do nothing. */
		}
	}

	if(I2TCounter_Float > SMon_P_I2TRating)
	{
		SMon_I2TError = 1u;
		Dem_SetDtc(0x53u, 0x2fu);
	}
	else if(0u == I2TCounter_Float && 1u == SMon_I2TError)
	{
		SMon_I2TError = 0u;
	}
	else
	{
		if(0x2fu == Dem_GetDtcStatus(0x53u))
		{
			Dem_SetDtc(0x53u, 0x2eu);
		}
		else
		{
			/* Do nothing. */
		}
	}
}

static float SMon_Batt_AbsF(float x)
{
	return (x < 0.0f) ? (-x) : x;
}

static float SMon_Batt_ClampF(float x, float lo, float hi)
{
	if (x < lo)
	{
		return lo;
	}
	else if (x > hi)
	{
		return hi;
	}
	else
	{
		return x;
	}
}

static float SMon_Batt_OcvToSoc(float ocv_v)
{
	static const float ocv_tbl[13] =
	{
		10.50f, 10.70f, 10.90f, 11.20f, 11.60f, 11.90f, 12.10f,
		12.22f, 12.32f, 12.42f, 12.52f, 12.63f, 12.75f
	};

	static const float soc_tbl[13] =
	{
		0.0f, 2.0f, 5.0f, 10.0f, 18.0f, 28.0f, 40.0f,
		50.0f, 60.0f, 70.0f, 80.0f, 90.0f, 100.0f
	};

	uint32_t i;

	if (ocv_v <= ocv_tbl[0u])
	{
		return soc_tbl[0u];
	}

	if (ocv_v >= ocv_tbl[12u])
	{
		return soc_tbl[12u];
	}

	for (i = 0u; i < 12u; i++)
	{
		if ((ocv_v >= ocv_tbl[i]) && (ocv_v < ocv_tbl[i + 1u]))
		{
			float x0 = ocv_tbl[i];
			float x1 = ocv_tbl[i + 1u];
			float y0 = soc_tbl[i];
			float y1 = soc_tbl[i + 1u];
			return y0 + ((ocv_v - x0) * (y1 - y0) / (x1 - x0));
		}
	}

	return 0.0f;
}

static float SMon_Batt_RintToSoh(float rint_ohm)
{
	float soh;

	if (rint_ohm <= SMon_P_BattNominalRint_Ohm)
	{
		soh = 100.0f;
	}
	else if (rint_ohm >= SMon_P_BattBadRint_Ohm)
	{
		soh = SMon_P_BattSoHMin_pct;
	}
	else
	{
		soh = 100.0f -
			  ((rint_ohm - SMon_P_BattNominalRint_Ohm) *
			   (100.0f - SMon_P_BattSoHMin_pct) /
			   (SMon_P_BattBadRint_Ohm - SMon_P_BattNominalRint_Ohm));
	}

	return SMon_Batt_ClampF(soh, SMon_P_BattSoHMin_pct, SMon_P_BattSoHMax_pct);
}

static float SMon_Batt_RestedVoltageToSohCap(float rested_v)
{
	if (rested_v <= 10.70f)
	{
		return 35.0f;
	}
	else if (rested_v <= 10.90f)
	{
		return 45.0f;
	}
	else if (rested_v <= 11.20f)
	{
		return 55.0f;
	}
	else if (rested_v <= 11.50f)
	{
		return 65.0f;
	}
	else if (rested_v <= 11.80f)
	{
		return 80.0f;
	}
	else if (rested_v <= 12.00f)
	{
		return 90.0f;
	}
	else
	{
		return 100.0f;
	}
}

static void SMon_Batt_InitIfNeeded(float v_t30_v, float v_l1_v, float i_raw_a)
{
	if (SMon_BattInt.initialized == 0u)
	{
		SMon_Battery.Voltage_V = v_t30_v;
		SMon_Battery.VoltageL1_V = v_l1_v;
		SMon_Battery.Current_A = i_raw_a;

		SMon_Battery.VoltageFilt_V = v_t30_v;
		SMon_Battery.VoltageL1Filt_V = v_l1_v;
		SMon_Battery.CurrentFilt_A = i_raw_a;

		SMon_Battery.NominalCapacity_Ah = SMon_P_BattNominalCapacity_Ah;

		if ((SMon_Battery.InternalResistance_Ohm < 0.001f) ||
			(SMon_Battery.InternalResistance_Ohm > 0.300f))
		{
			SMon_Battery.InternalResistance_Ohm = SMon_P_BattNominalRint_Ohm;
		}

		if ((SMon_Battery.SoC_pct < 0.0f) || (SMon_Battery.SoC_pct > 100.0f))
		{
			SMon_Battery.SoC_pct = SMon_Batt_OcvToSoc(v_t30_v);
		}

		SMon_Battery.SoC_pct = SMon_Batt_ClampF(SMon_Battery.SoC_pct,
												SMon_P_BattMinSoC_pct,
												SMon_P_BattMaxSoC_pct);

		SMon_Battery.SoC_CC_pct = SMon_Battery.SoC_pct;
		SMon_Battery.SoC_OCV_pct = SMon_Batt_OcvToSoc(v_t30_v);
		SMon_Battery.SoH_Rint_pct = SMon_Batt_RintToSoh(SMon_Battery.InternalResistance_Ohm);
		SMon_Battery.SoH_VoltageCap_pct = 100.0f;
		SMon_Battery.SoH_pct = SMon_Battery.SoH_Rint_pct;
		SMon_Battery.AvailableCapacity_Ah =
			SMon_Battery.NominalCapacity_Ah * (SMon_Battery.SoH_pct / 100.0f);

		if (SMon_Battery.AvailableCapacity_Ah < 1.0f)
		{
			SMon_Battery.AvailableCapacity_Ah = 1.0f;
		}

		SMon_Battery.State = SMON_BATT_STATE_REST;
		SMon_Battery.Charging = 0u;
		SMon_Battery.Discharging = 0u;
		SMon_Battery.ChargerPathActive = 0u;
		SMon_Battery.BatteryRested = 0u;
		SMon_Battery.ValidOcvCalibration = 0u;

		if ((SMon_Battery.WorstRestedVoltage_V < 0.0f) ||
			(SMon_Battery.WorstRestedVoltage_V > 20.0f))
		{
			SMon_Battery.WorstRestedVoltage_V = 0.0f;
			SMon_Battery.WorstRestedVoltageValid = 0u;
		}

		SMon_BattInt.prevState = SMON_BATT_STATE_REST;
		SMon_BattInt.pendingState = SMON_BATT_STATE_REST;
		SMon_BattInt.prevChargerPathActive = 0u;
		SMon_BattInt.restReferenceV = v_t30_v;
		SMon_BattInt.initialized = 1u;
	}
}

static void SMon_Batt_UpdateChargePath(float delta_v)
{
	if (SMon_Battery.ChargerPathActive == 0u)
	{
		if (delta_v >= SMon_P_BattChargePathDeltaOn_V)
		{
			if (SMon_BattInt.chargePathOnTicks < SMon_P_WaitTimeOVUV)
			{
				SMon_BattInt.chargePathOnTicks++;
			}

			if (SMon_BattInt.chargePathOnTicks >= SMon_P_WaitTimeOVUV)
			{
				SMon_Battery.ChargerPathActive = 1u;
				SMon_BattInt.chargePathOffTicks = 0u;
			}
		}
		else
		{
			SMon_BattInt.chargePathOnTicks = 0u;
		}
	}
	else
	{
		if (delta_v <= SMon_P_BattChargePathDeltaOff_V)
		{
			if (SMon_BattInt.chargePathOffTicks < SMon_P_WaitTimeOVUV)
			{
				SMon_BattInt.chargePathOffTicks++;
			}

			if (SMon_BattInt.chargePathOffTicks >= SMon_P_WaitTimeOVUV)
			{
				SMon_Battery.ChargerPathActive = 0u;
				SMon_BattInt.chargePathOnTicks = 0u;
			}
		}
		else
		{
			SMon_BattInt.chargePathOffTicks = 0u;
		}
	}
}

static uint8_t SMon_Batt_CalcRawState(float i_filt_a)
{
	float enter_thr = SMon_P_BattCurrentDeadband_A + SMon_P_BattCurrentHys_A;
	float exit_thr  = SMon_P_BattCurrentDeadband_A;

	if ((SMon_BattInt.prevState == SMON_BATT_STATE_CHARGE && i_filt_a <= (-exit_thr)) ||
		(i_filt_a <= (-enter_thr)))
	{
		return SMON_BATT_STATE_CHARGE;
	}

	if ((SMon_BattInt.prevState == SMON_BATT_STATE_DISCHARGE && i_filt_a >= exit_thr) ||
		(i_filt_a >= enter_thr))
	{
		return SMON_BATT_STATE_DISCHARGE;
	}

	return SMON_BATT_STATE_REST;
}

static void SMon_Batt_OnStateEntry(uint8_t new_state)
{
	if (new_state == SMON_BATT_STATE_CHARGE)
	{
		SMon_BattInt.chargeCurrentSum_A = 0.0f;
		SMon_BattInt.chargeCurrentCnt = 0u;
		SMon_Battery.AvgChargeCurrent_A = 0.0f;
		SMon_Battery.TimeToFull_h = 0.0f;
		SMon_Battery.BatteryRested = 0u;
		SMon_Battery.ValidOcvCalibration = 0u;
		SMon_BattInt.restTicks = 0u;
	}
	else if (new_state == SMON_BATT_STATE_DISCHARGE)
	{
		SMon_BattInt.dischargeCurrentSum_A = 0.0f;
		SMon_BattInt.dischargeCurrentCnt = 0u;
		SMon_Battery.AvgDischargeCurrent_A = 0.0f;
		SMon_Battery.RuntimeRemaining_h = 0.0f;
		SMon_Battery.BatteryRested = 0u;
		SMon_Battery.ValidOcvCalibration = 0u;
		SMon_BattInt.restTicks = 0u;
	}
	else
	{
		SMon_BattInt.restTicks = 0u;
		SMon_BattInt.restReferenceV = SMon_Battery.VoltageFilt_V;
	}

	SMon_BattInt.prevState = new_state;
}

static void SMon_Batt_UpdateState(float i_filt_a)
{
	uint8_t raw_state = SMon_Batt_CalcRawState(i_filt_a);

	if (raw_state != SMon_BattInt.prevState)
	{
		if (raw_state != SMon_BattInt.pendingState)
		{
			SMon_BattInt.pendingState = raw_state;
			SMon_BattInt.pendingStateTicks = 1u;
		}
		else
		{
			if (SMon_BattInt.pendingStateTicks < SMon_P_WaitTimeOVUV)
			{
				SMon_BattInt.pendingStateTicks++;
			}

			if (SMon_BattInt.pendingStateTicks >= SMon_P_WaitTimeOVUV)
			{
				SMon_Batt_OnStateEntry(raw_state);
				SMon_BattInt.pendingStateTicks = 0u;
			}
		}
	}
	else
	{
		SMon_BattInt.pendingState = raw_state;
		SMon_BattInt.pendingStateTicks = 0u;
	}

	SMon_Battery.State = SMon_BattInt.prevState;
	SMon_Battery.Charging = (SMon_Battery.State == SMON_BATT_STATE_CHARGE) ? 1u : 0u;
	SMon_Battery.Discharging = (SMon_Battery.State == SMON_BATT_STATE_DISCHARGE) ? 1u : 0u;
}

static void SMon_Batt_HandleChargePathEdge(void)
{
	if (SMon_Battery.ChargerPathActive != SMon_BattInt.prevChargerPathActive)
	{
		SMon_BattInt.restTicks = 0u;
		SMon_Battery.BatteryRested = 0u;
		SMon_Battery.ValidOcvCalibration = 0u;

		if (SMon_Battery.ChargerPathActive != 0u)
		{
			SMon_BattInt.chargeCurrentSum_A = 0.0f;
			SMon_BattInt.chargeCurrentCnt = 0u;
			SMon_Battery.AvgChargeCurrent_A = 0.0f;
			SMon_Battery.TimeToFull_h = 0.0f;
		}
		else
		{
			SMon_BattInt.dischargeCurrentSum_A = 0.0f;
			SMon_BattInt.dischargeCurrentCnt = 0u;
			SMon_Battery.AvgDischargeCurrent_A = 0.0f;
			SMon_Battery.RuntimeRemaining_h = 0.0f;
		}

		SMon_BattInt.prevChargerPathActive = SMon_Battery.ChargerPathActive;
	}
}

static void SMon_Batt_UpdateRestState(void)
{
	float rest_curr_thr = SMon_P_BattRestDetectCurrent_A;

	if ((SMon_Battery.ChargerPathActive == 0u) &&
		(SMon_Batt_AbsF(SMon_Battery.CurrentFilt_A) <= rest_curr_thr))
	{
		if (SMon_BattInt.restTicks == 0u)
		{
			SMon_BattInt.restReferenceV = SMon_Battery.VoltageFilt_V;
			SMon_BattInt.restTicks = 1u;
		}
		else
		{
			if (SMon_Batt_AbsF(SMon_Battery.VoltageFilt_V - SMon_BattInt.restReferenceV) <= SMon_P_BattRestVoltDelta_V)
			{
				if (SMon_BattInt.restTicks < SMon_P_BattRestTimeTicks)
				{
					SMon_BattInt.restTicks++;
				}
			}
			else
			{
				SMon_BattInt.restReferenceV = SMon_Battery.VoltageFilt_V;
				SMon_BattInt.restTicks = 1u;
			}
		}

		SMon_Battery.BatteryRested =
			(SMon_BattInt.restTicks >= SMon_P_BattRestTimeTicks) ? 1u : 0u;

		if (SMon_Battery.BatteryRested != 0u)
		{
			SMon_BattInt.lastRestVoltage_V = SMon_Battery.VoltageFilt_V;
			SMon_BattInt.lastRestVoltageValid = 1u;

			if ((SMon_Battery.WorstRestedVoltageValid == 0u) ||
				(SMon_Battery.VoltageFilt_V < SMon_Battery.WorstRestedVoltage_V))
			{
				SMon_Battery.WorstRestedVoltage_V = SMon_Battery.VoltageFilt_V;
				SMon_Battery.WorstRestedVoltageValid = 1u;
			}
		}
	}
	else
	{
		SMon_BattInt.restTicks = 0u;
		SMon_BattInt.restReferenceV = SMon_Battery.VoltageFilt_V;
		SMon_Battery.BatteryRested = 0u;
	}
}

static void SMon_Batt_UpdateRintFromRestStep(float i_discharge_eff_a)
{
	static uint32_t stepTicks = 0u;
	float r_inst;

	if ((SMon_Battery.State != SMON_BATT_STATE_DISCHARGE) ||
		(SMon_BattInt.lastRestVoltageValid == 0u) ||
		(i_discharge_eff_a < SMon_P_BattRintMinStep_A))
	{
		stepTicks = 0u;
		return;
	}

	if (stepTicks < SMon_P_WaitTimeOVUV)
	{
		stepTicks++;
		return;
	}

	r_inst = (SMon_BattInt.lastRestVoltage_V - SMon_Battery.VoltageFilt_V) / i_discharge_eff_a;

	if ((r_inst >= 0.001f) && (r_inst <= 0.300f))
	{
		SMon_Battery.InternalResistance_Ohm +=
			SMon_P_BattAlphaRint * (r_inst - SMon_Battery.InternalResistance_Ohm);
		SMon_BattInt.lastRestVoltageValid = 0u;
	}

	stepTicks = 0u;
}

static void SMon_BatteryData(void)
{
	float v_t30_v = 0.0f;
	float v_l1_v = 0.0f;
	float i_raw_a = 0.0f;
	float delta_l1_t30_v = 0.0f;
	float i_charge_eff_a = 0.0f;
	float i_discharge_eff_a = 0.0f;
	float i_eff_signed_a = 0.0f;
	float dAh_charge = 0.0f;
	float dAh_discharge = 0.0f;
	float cap_ah = 0.0f;
	float conf = 0.0f;

	v_t30_v = ((float)SMon_VfbT30) / 1000.0f;
	v_l1_v  = ((float)SMon_VfbL1) / 1000.0f;
	i_raw_a = SMon_ISenseL1_Float;

	SMon_Batt_InitIfNeeded(v_t30_v, v_l1_v, i_raw_a);

	SMon_Battery.Voltage_V = v_t30_v;
	SMon_Battery.VoltageL1_V = v_l1_v;
	SMon_Battery.Current_A = i_raw_a;
	SMon_Battery.NominalCapacity_Ah = SMon_P_BattNominalCapacity_Ah;

	SMon_Battery.VoltageFilt_V +=
		SMon_P_BattAlphaVolt * (v_t30_v - SMon_Battery.VoltageFilt_V);

	SMon_Battery.VoltageL1Filt_V +=
		SMon_P_BattAlphaVolt * (v_l1_v - SMon_Battery.VoltageL1Filt_V);

	SMon_Battery.CurrentFilt_A +=
		SMon_P_BattAlphaCurr * (i_raw_a - SMon_Battery.CurrentFilt_A);

	delta_l1_t30_v = SMon_Battery.VoltageL1Filt_V - SMon_Battery.VoltageFilt_V;
	SMon_Battery.DeltaL1T30_V = delta_l1_t30_v;

	SMon_Batt_UpdateChargePath(delta_l1_t30_v);
	SMon_Batt_HandleChargePathEdge();
	SMon_Batt_UpdateState(SMon_Battery.CurrentFilt_A);
	SMon_Batt_UpdateRestState();

	{
		float soh_rint;
		float soh_cap;

		soh_rint = SMon_Batt_RintToSoh(SMon_Battery.InternalResistance_Ohm);
		soh_cap = 100.0f;

		if (SMon_Battery.WorstRestedVoltageValid != 0u)
		{
			soh_cap = SMon_Batt_RestedVoltageToSohCap(SMon_Battery.WorstRestedVoltage_V);
		}
		else if ((SMon_Battery.BatteryRested != 0u) &&
				 (SMon_Battery.ChargerPathActive == 0u))
		{
			soh_cap = SMon_Batt_RestedVoltageToSohCap(SMon_Battery.VoltageFilt_V);
		}

		SMon_Battery.SoH_Rint_pct = soh_rint;
		SMon_Battery.SoH_VoltageCap_pct = soh_cap;
		SMon_Battery.SoH_pct = (soh_rint < soh_cap) ? soh_rint : soh_cap;
	}

	SMon_Battery.AvailableCapacity_Ah =
		SMon_Battery.NominalCapacity_Ah * (SMon_Battery.SoH_pct / 100.0f);

	if (SMon_Battery.AvailableCapacity_Ah < 1.0f)
	{
		SMon_Battery.AvailableCapacity_Ah = 1.0f;
	}

	cap_ah = SMon_Battery.AvailableCapacity_Ah;

	if (SMon_Battery.CurrentFilt_A >= SMon_P_BattCurrentDeadband_A)
	{
		i_discharge_eff_a = SMon_Battery.CurrentFilt_A - SMon_P_BattCurrentDeadband_A;
	}
	else
	{
		i_discharge_eff_a = 0.0f;
	}

	if (SMon_Battery.CurrentFilt_A <= (-SMon_P_BattCurrentDeadband_A))
	{
		i_charge_eff_a = (-SMon_Battery.CurrentFilt_A) - SMon_P_BattCurrentDeadband_A;
	}
	else
	{
		i_charge_eff_a = 0.0f;
	}

	i_eff_signed_a = i_discharge_eff_a - i_charge_eff_a;

	dAh_charge = i_charge_eff_a * SMON_BATT_DT_H;
	dAh_discharge = i_discharge_eff_a * SMON_BATT_DT_H;

	SMon_Battery.SoC_CC_pct +=
		((dAh_charge * SMon_P_BattChargeEfficiency) -
		 dAh_discharge) * 100.0f / cap_ah;

	SMon_Battery.SoC_CC_pct =
		SMon_Batt_ClampF(SMon_Battery.SoC_CC_pct,
						 SMon_P_BattMinSoC_pct,
						 SMon_P_BattMaxSoC_pct);

	if (SMon_Battery.BatteryRested != 0u)
	{
		SMon_Battery.OcvEst_V = SMon_Battery.VoltageFilt_V;
		SMon_Battery.ValidOcvCalibration = 1u;
		SMon_Battery.SoC_OCV_pct = SMon_Batt_OcvToSoc(SMon_Battery.OcvEst_V);
	}
	else
	{
		SMon_Battery.ValidOcvCalibration = 0u;
		/* keep previous SoC_OCV_pct */
	}

	if (SMon_Battery.BatteryRested != 0u)
	{
		SMon_Battery.SoC_CC_pct +=
			SMon_P_BattOcvCorrectionGain *
			(SMon_Battery.SoC_OCV_pct - SMon_Battery.SoC_CC_pct);
	}
	else if ((SMon_Battery.State == SMON_BATT_STATE_REST) &&
			 (SMon_Batt_AbsF(SMon_Battery.CurrentFilt_A) <=
			  (SMon_P_BattCurrentDeadband_A + 0.1f)))
	{
		SMon_Battery.SoC_CC_pct +=
			(0.25f * SMon_P_BattOcvCorrectionGain) *
			(SMon_Battery.SoC_OCV_pct - SMon_Battery.SoC_CC_pct);
	}
	else
	{
		/* no OCV correction under active charge/discharge */
	}

	SMon_Battery.SoC_CC_pct =
		SMon_Batt_ClampF(SMon_Battery.SoC_CC_pct,
						 SMon_P_BattMinSoC_pct,
						 SMon_P_BattMaxSoC_pct);

	SMon_Battery.SoC_pct = SMon_Battery.SoC_CC_pct;

	SMon_Batt_UpdateRintFromRestStep(i_discharge_eff_a);

	{
		float soh_rint;
		float soh_cap;

		soh_rint = SMon_Batt_RintToSoh(SMon_Battery.InternalResistance_Ohm);
		soh_cap = 100.0f;

		if (SMon_Battery.WorstRestedVoltageValid != 0u)
		{
			soh_cap = SMon_Batt_RestedVoltageToSohCap(SMon_Battery.WorstRestedVoltage_V);
		}
		else if ((SMon_Battery.BatteryRested != 0u) &&
				 (SMon_Battery.ChargerPathActive == 0u))
		{
			soh_cap = SMon_Batt_RestedVoltageToSohCap(SMon_Battery.VoltageFilt_V);
		}

		SMon_Battery.SoH_Rint_pct = soh_rint;
		SMon_Battery.SoH_VoltageCap_pct = soh_cap;
		SMon_Battery.SoH_pct = (soh_rint < soh_cap) ? soh_rint : soh_cap;
	}

	SMon_Battery.AvailableCapacity_Ah =
		SMon_Battery.NominalCapacity_Ah * (SMon_Battery.SoH_pct / 100.0f);

	if (SMon_Battery.AvailableCapacity_Ah < 1.0f)
	{
		SMon_Battery.AvailableCapacity_Ah = 1.0f;
	}

	SMon_Battery.Charge_Ah_Acc += dAh_charge * SMon_P_BattChargeEfficiency;
	SMon_Battery.Discharge_Ah_Acc += dAh_discharge;
	SMon_Battery.Net_Ah_Acc +=
		(dAh_charge * SMon_P_BattChargeEfficiency) - dAh_discharge;

	SMon_Battery.Charge_Wh_Acc +=
		(SMon_Battery.VoltageFilt_V * dAh_charge * SMon_P_BattChargeEfficiency);

	SMon_Battery.Discharge_Wh_Acc +=
		(SMon_Battery.VoltageFilt_V * dAh_discharge);

	SMon_Battery.Net_Wh_Acc +=
		(SMon_Battery.VoltageFilt_V *
		 ((dAh_charge * SMon_P_BattChargeEfficiency) - dAh_discharge));

	if (i_charge_eff_a > 0.0f)
	{
		SMon_BattInt.chargeCurrentSum_A += i_charge_eff_a;
		SMon_BattInt.chargeCurrentCnt++;
		SMon_Battery.AvgChargeCurrent_A =
			SMon_BattInt.chargeCurrentSum_A / (float)SMon_BattInt.chargeCurrentCnt;
	}

	if (i_discharge_eff_a > 0.0f)
	{
		SMon_BattInt.dischargeCurrentSum_A += i_discharge_eff_a;
		SMon_BattInt.dischargeCurrentCnt++;
		SMon_Battery.AvgDischargeCurrent_A =
			SMon_BattInt.dischargeCurrentSum_A / (float)SMon_BattInt.dischargeCurrentCnt;
	}

	SMon_Battery.Power_W = SMon_Battery.VoltageFilt_V * i_eff_signed_a;
	SMon_Battery.ChargePower_W =
		(i_charge_eff_a > 0.0f) ? (SMon_Battery.VoltageFilt_V * i_charge_eff_a) : 0.0f;
	SMon_Battery.DischargePower_W =
		(i_discharge_eff_a > 0.0f) ? (SMon_Battery.VoltageFilt_V * i_discharge_eff_a) : 0.0f;

	if ((SMon_Battery.State == SMON_BATT_STATE_DISCHARGE) &&
		(SMon_Battery.AvgDischargeCurrent_A > 0.05f))
	{
		SMon_Battery.RuntimeRemaining_h =
			((SMon_Battery.SoC_pct / 100.0f) * SMon_Battery.AvailableCapacity_Ah) /
			SMon_Battery.AvgDischargeCurrent_A;
	}
	else
	{
		SMon_Battery.RuntimeRemaining_h = 0.0f;
	}

	if ((SMon_Battery.State == SMON_BATT_STATE_CHARGE) &&
		(SMon_Battery.AvgChargeCurrent_A > 0.05f))
	{
		SMon_Battery.TimeToFull_h =
			(((100.0f - SMon_Battery.SoC_pct) / 100.0f) *
			 SMon_Battery.AvailableCapacity_Ah) /
			(SMon_Battery.AvgChargeCurrent_A * SMon_P_BattChargeEfficiency);
	}
	else
	{
		SMon_Battery.TimeToFull_h = 0.0f;
	}

	SMon_Battery.WeakBattery =
		((SMon_Battery.SoH_pct <= 65.0f) ||
		 ((SMon_Battery.BatteryRested != 0u) &&
		  (SMon_Battery.VoltageFilt_V <= SMon_P_BattWeakVolt_V)) ||
		 (SMon_Battery.SoC_pct <= 20.0f)) ? 1u : 0u;

	SMon_Battery.DeepDischarge =
		(((SMon_Battery.BatteryRested != 0u) &&
		  (SMon_Battery.VoltageFilt_V <= SMon_P_BattDeepDischargeVolt_V)) ||
		 (SMon_Battery.SoC_pct <= 8.0f)) ? 1u : 0u;

	SMon_Battery.CrankingEvent =
		((SMon_Battery.Voltage_V <= SMon_P_BattCrankVolt_V) &&
		 (i_discharge_eff_a > 5.0f)) ? 1u : 0u;

	conf = 35.0f;

	if (SMon_Battery.BatteryRested != 0u)
	{
		conf += 25.0f;
	}

	if ((SMon_Battery.InternalResistance_Ohm >= 0.001f) &&
		(SMon_Battery.InternalResistance_Ohm <= 0.300f))
	{
		conf += 15.0f;
	}

	if (SMon_Battery.State == SMON_BATT_STATE_CHARGE)
	{
		conf += 10.0f;
	}
	else if (SMon_Battery.State == SMON_BATT_STATE_DISCHARGE)
	{
		conf += 10.0f;
	}

	if (SMon_Battery.WeakBattery != 0u)
	{
		conf -= 5.0f;
	}

	if (SMon_Battery.DeepDischarge != 0u)
	{
		conf -= 10.0f;
	}

	SMon_Battery.Confidence_pct =
		(uint8_t)SMon_Batt_ClampF(conf, 0.0f, 100.0f);
}

static void SMon_ProcessShortToPlusTest(void)
{
	static uint32_t localDischargeTimer = 0u; // normal discharge counter
	static uint32_t localLowDisTimer = 0u; // very low voltage discharge counter
	static uint32_t localS2BCounter = 0u; // longer case discharge time counter

	if(1u != SMon_RequestPhysicalStatus)
	{
		if(0u == SMon_ShortToPlusTest)
		{
			SMon_ShortToPlusTest = 1u; // start short to plus test
		}
		else
		{
			/* Do nothing. */
		}
	}
	else if(1u == SMon_RequestPhysicalStatus)
	{
		SMon_ShortToPlusTest = 0u; // reset short to plus test status
		localDischargeTimer = 0u; // reset normal discharge counter
		localLowDisTimer = 0u; // reset very low voltage discharge counter
		localS2BCounter = 0u; // reset longer case discharge time counter
		SMon_S2BErrorStatus = 0u;
	}
	else
	{
		/* Do nothing. */
	}

	if(0u != SMon_ShortToPlusTest)
	{
		if(0u == localDischargeTimer) // "first call"
		{
			localDischargeTimer = SMon_MainCnt; // time-stamp
			localLowDisTimer = SMon_MainCnt; // time-stamp
			localS2BCounter = SMon_MainCnt; // time-stamp
		}
		else
		{
			switch(SMon_ShortToPlusTest) // short-to-plus test phases
			{

			case 1u: // 50% of voltage discharge time check

				if(SMon_P_DischargeTimeCycles <= (SMon_MainCnt - localDischargeTimer))
				{
					if(SMon_T30P50 <= SMon_VfbL1)
					{
						Dem_SetDtc(0x52, 0x2f);

						SMon_ShortToPlusTest = 2u; // go-to next phase
						SMon_S2BErrorStatus = 1u;
					}
					else
					{
						/* Do nothing. */
					}
				}
				else
				{
					if(SMon_T30P50 > SMon_VfbL1) // abort this test phase
					{
						SMon_ShortToPlusTest = 2u; // go-to next phase
						SMon_S2BErrorStatus = 0u;

						if(0x2f == Dem_GetDtcStatus(0x52u))
						{
							Dem_SetDtc(0x52, 0x2e);
						}
						else
						{
							/* Do nothing. */
						}
					}
					else
					{
						/* Do nothing. */
					}
				}

				break;

			case 2u:

				if(SMon_P_LowDisTimeCyc <= (SMon_MainCnt - localLowDisTimer))
				{
					if((SMon_VfbT30 * 3 / 10) <= SMon_VfbL1)
					{
						Dem_SetDtc(0x5f, 0x2f);

						SMon_ShortToPlusTest = 3u; // go-to next phase
						SMon_S2BErrorStatus = 2u;
					}
					else
					{
						/* Do nothing. */
					}
				}
				else
				{
					if((SMon_VfbT30 * 3 / 10) > SMon_VfbL1) // abort this test phase
					{
						SMon_ShortToPlusTest = 3u; // go-to next phase
						SMon_S2BErrorStatus = 0u;

						if(0x2f == Dem_GetDtcStatus(0x5fu))
						{
							Dem_SetDtc(0x5f, 0x2e);
						}
						else
						{
							/* Do nothing. */
						}
					}
					else
					{
						/* Do nothing. */
					}
				}

				break;

			case 3u:

				if(SMon_P_LongDischargeTimeCycles <= (SMon_MainCnt - localS2BCounter))
				{
					if(SMon_P_LowVoltage <= SMon_VfbL1)
					{
						Dem_SetDtc(0x60, 0x2f);
						SMon_S2BErrorStatus = 3u;
						SMon_ShortToPlusTest = 4u; // finish short to plus test
					}
					else
					{
						/* Do nothing. */
					}
				}
				else
				{
					if(SMon_P_LowVoltage > SMon_VfbL1) // abort this test phase
					{
						SMon_ShortToPlusTest = 4u; // finish short to plus test
						SMon_S2BErrorStatus = 0u;

						if(0x2f == Dem_GetDtcStatus(0x60u))
						{
							Dem_SetDtc(0x60, 0x2e);

						}
						else
						{
							/* Do nothing. */
						}
					}
					else
					{
						/* Do nothing. */
					}
				}

				break;

			default: // do nothing

				break;

			}
		}
	}
	else
	{
		/* Do nothing. */
	}
}

static void SMon_ProcessLoadCurrentState(void)
{
	static uint8_t pSMon_CalculatedCommand = 0u;
	static uint8_t inhibitReactivation = 0u;
	uint8_t calculatedCommand;
	uint8_t anyFaultActive;
	uint8_t risingEdgeCmd;
	uint32_t thresh_on;
	uint32_t thresh_off;

	SMon_T30P50 = (SMon_VfbT30 * 5u) / 10u;
	thresh_on  = SMon_T30P50 + SMon_P_StatusVoltageL1Filter;
	thresh_off = (SMon_T30P50 > SMon_P_StatusVoltageL1Filter) ? (SMon_T30P50 - SMon_P_StatusVoltageL1Filter) : 0u;

	if ((SMon_L1ST == 0u) && (SMon_VfbL1 >= thresh_on))
	{
		SMon_L1ST = 1u;
	}
	else if ((SMon_L1ST == 1u) && (SMon_VfbL1 <= thresh_off))
	{
		SMon_L1ST = 0u;
	}
	else
	{
		/* no change */
	}

	if (Dcm_LoadStatus == 1u)
	{
		calculatedCommand = 1u;
	}
	else if (Dcm_LoadStatus == 0u)
	{
		calculatedCommand = 0u;
	}
	else if (SMon_CmdStat == 1u)
	{
		calculatedCommand = 1u;
	}
	else if (SMon_CmdStat == 0u)
	{
		calculatedCommand = 0u;
	}
	else if (EcuM_WUPLine == 1u)
	{
		calculatedCommand = 1u;
	}
	else if (SMon_ExternalChargerDetected == 1u)
	{
		calculatedCommand = 1u;
	}
	else
	{
		calculatedCommand = 0u;
	}

	SMon_CalculatedCommand = calculatedCommand;

	anyFaultActive =
			(SMon_CLS_Failure != 0u) ||
			(SMon_L1_UVStatus  != 0u) ||
			(SMon_NtcError     != 0u) ||
			(SMon_ECU_OV       != 0u) ||
			(SMon_ECU_UV       != 0u);

	/* Latch inhibit when ANY voltage fault appears */
	if ((SMon_L1_UVStatus == 1u) ||
			(SMon_ECU_OV      == 1u) ||
			(SMon_ECU_UV      == 1u))
	{
		inhibitReactivation = 1u;
	}
	else
	{
		/* no change */
	}

	/* Command rising edge detection */
	risingEdgeCmd =
			(pSMon_CalculatedCommand == 0u) &&
			(SMon_CalculatedCommand  == 1u);

	/* Clear inhibit ONLY on command rising edge */
	if (risingEdgeCmd != 0u)
	{
		inhibitReactivation = 0u;
	}
	else
	{
		/* no change */
	}

	if ((SMon_CalculatedCommand == 1u) &&
			(anyFaultActive == 0u) &&
			(inhibitReactivation == 0u))
	{
		SMon_RequestPhysicalStatus = 1u;
	}
	else
	{
		SMon_RequestPhysicalStatus = 0u;
	}

	pSMon_CalculatedCommand = SMon_CalculatedCommand;
}

static void SMon_ProcessEcuVoltageState(void)
{
	static uint32_t CounterUVKL30 = 0u; // UV Counter For De-Bounce
	static uint32_t CounterOVKL30 = 0u; // OV Counter For De-Bounce

	if(SMon_P_UV_KL30 <= SMon_VfbT30 && SMon_P_OV_KL30 >= SMon_VfbT30) // UV OV checks
	{
		CounterUVKL30 = 0u; // reset counters
		CounterOVKL30 = 0u; // reset counters
		SMon_ECU_UV = 0u;
		SMon_ECU_OV = 0u;
	}
	else
	{
		if(SMon_P_UV_KL30 > SMon_VfbT30) // under-voltage
		{
			if(0u == CounterUVKL30) // "first call"
			{
				CounterUVKL30 = SMon_MainCnt; // time-stamp
			}
			else
			{
				if(SMon_P_WaitTimeOVUV < (SMon_MainCnt - CounterUVKL30)) // de-bounce for UV
				{
					SMon_ECU_UV = 1u;
					Dem_SetDtc(0x50, 0x2f);
				}
				else
				{
					SMon_ECU_UV = 0u;
					if(0x2f == Dem_GetDtcStatus(0x50))
					{
						Dem_SetDtc(0x50, 0x2e);
					}
					else
					{
						/* Do nothing. */
					}
				}
			}
		}
		else
		{
			CounterUVKL30 = 0u; // reset counter
		}

		if(SMon_P_OV_KL30 < SMon_VfbT30) // over-voltage
		{
			if(0u == CounterOVKL30) // "first call"
			{
				CounterOVKL30 = SMon_MainCnt; // time-stamp
			}
			else
			{
				if(SMon_P_WaitTimeOVUV < (SMon_MainCnt - CounterOVKL30)) // de-bounce for OV - 300ms
				{
					SMon_ECU_OV = 1u;
					Dem_SetDtc(0x51, 0x2f);

				}
				else
				{
					SMon_ECU_OV = 0u;

					if(0x2f == Dem_GetDtcStatus(0x51))
					{
						Dem_SetDtc(0x51, 0x2e);

					}
					else
					{
						/* Do nothing. */
					}
				}
			}
		}
		else
		{
			CounterOVKL30 = 0u; // reset counter
		}
	}
}

static void SMon_ProcessLoadErrorStatus(void)
{
	static uint8_t pSMon_I2TError = 0u;
	static uint8_t pSMon_CLS_Failure = 0u;
	static uint8_t pSMon_CmdStat = 0u;
	static uint32_t localTimeStamp = 0u;
	static uint32_t localTimeStamp2 = 0u;
	static uint32_t localTimeStamp3 = 0u;
	static uint8_t pCanH_VehicleStatus = 0u;
	static uint32_t l1_uv_recovery_ts = 0u;

	if(1u == SMon_LockSupply)
	{
		if( ( ( ( 1u ) == ( pCanH_VehicleStatus ) ) ||
				( ( 2u ) == ( pCanH_VehicleStatus ) ) ||
				( ( 3u ) == ( pCanH_VehicleStatus ) ) ) &&
				( ( ( 4u ) == ( CanH_VehicleStatus ) ) ||
						( ( 6u ) == ( CanH_VehicleStatus ) ) ) )
		{
			SMon_LockSupply = 0u;
			SMon_RetryCnt = 0u;
		}
		else
		{
			/* Do nothing. */
		}
	}
	else
	{
		/* Do nothing. */
	}

	if(pCanH_VehicleStatus != CanH_VehicleStatus)
	{
		pCanH_VehicleStatus = CanH_VehicleStatus;
	}
	{
		/* Do nothing. */
	}

	if (SMon_NTC_Temperature_L1 > SMon_P_NTCTemperatureMax)
	{
	    if (localTimeStamp3 == 0u)
	    {
	        localTimeStamp3 = SMon_MainCnt;
	    }

	    if ((SMon_MainCnt - localTimeStamp3) >= SMon_P_WaitTimeOVUV)
	    {
	        if (SMon_NtcError == 0u)
	        {
	            SMon_RequestPhysicalStatus = 0u;
	            SMon_NtcError = 1u;
	            Dem_SetDtc(0x58u, 0x2f);
	        }
	    }
	}
	else if (SMon_NTC_Temperature_L1 < SMon_P_NTCTemperatureRelease)
	{
	    if (localTimeStamp3 == 0u)
	    {
	        localTimeStamp3 = SMon_MainCnt;
	    }

	    if ((SMon_MainCnt - localTimeStamp3) >= SMon_P_WaitTimeOVUV)
	    {
	        if (SMon_NtcError == 1u)
	        {
	            SMon_NtcError = 0u;

	            if (Dem_GetDtcStatus(0x58u) == 0x2f)
	            {
	                Dem_SetDtc(0x58u, 0x2e);
	            }
	        }
	    }
	}
	else
	{
	    localTimeStamp3 = 0u;
	}

	if(SMon_P_ExternalChargerThreshold > SMon_ISenseL1_ExtChISense)
	{
		if(0u == localTimeStamp2)
		{
			localTimeStamp2 = SMon_MainCnt;
		}
		else
		{
			if(SMon_P_WaitTimeOVUV < (SMon_MainCnt - localTimeStamp2))
			{
				SMon_ExternalChargerDetected = 1u;
				SMon_RequestPhysicalStatus = 1u;

				Dem_SetDtc(0x59u, 0x2f);

				localTimeStamp2 = 0;
			}
			else
			{
				/* Do nothing. */
			}
		}
	}
	else if(SMon_ISenseL1_ExtChISense > -0.1f)
	{
		if(0u == localTimeStamp2)
		{
			localTimeStamp2 = SMon_MainCnt;
		}
		else
		{
			if(SMon_P_WaitTimeOVUV < (SMon_MainCnt - localTimeStamp2))
			{
				SMon_ExternalChargerDetected = 0u;

				if(0x2f == Dem_GetDtcStatus(0x59u))
				{
					Dem_SetDtc(0x59u, 0x2e);
				}
				else
				{
					/* Do nothing. */
				}

				localTimeStamp2 = 0;

			}
			else
			{
				/* Do nothing. */
			}
		}
	}
	else
	{
		/* Do nothing. */
	}

	if(1u == SMon_CLS_Failure)
	{
		if(0u == localTimeStamp)
		{
			localTimeStamp = SMon_MainCnt;
		}
		else
		{
			if(SMon_P_ClsFailureWaitTime < (SMon_MainCnt - localTimeStamp))
			{
				SMon_CLS_Failure = 0u;
				localTimeStamp = 0u;
			}
			else
			{
				/* Do nothing. */
			}
		}
	}
	else
	{
		/* Do nothing. */
	}

	if( ( 1u == SMon_ECU_OV || 1u == SMon_ECU_UV ) )
	{
		SMon_RequestPhysicalStatus = 0u;
	}
	else
	{
		/* Do nothing. */
	}

	if(1u == SMon_I2TError)
	{
		SMon_RequestPhysicalStatus = 0u;
	}
	else
	{
		/* Do nothing. */
	}

	if(1u == pSMon_CLS_Failure && 0u == SMon_CLS_Failure && 0u == SMon_LockSupply)
	{
		pSMon_CLS_Failure = SMon_CLS_Failure;
		SMon_RetryCnt++;
	}
	else
	{
		/* Do nothing. */
	}

	if(1u == pSMon_I2TError && 0u == SMon_I2TError && 0u == SMon_LockSupply)
	{
		pSMon_I2TError = SMon_I2TError;
		SMon_RetryCnt++;
	}
	else
	{
		/* Do nothing. */
	}

	if(SMon_P_Rtcntmax == SMon_RetryCnt)
	{
		SMon_LockSupply = 1u;
		Dem_SetDtc(0x54, 0x2f);
	}
	else
	{
		/* Do nothing. */
	}

	if(0u != SMon_LockSupply)
	{
		SMon_RequestPhysicalStatus = 0u;
	}
	else
	{
		/* Do nothing. */
	}

	if (SMon_L1_UVStatus == 1u)
	{
		/* Keep fault latched */
		SMon_RequestPhysicalStatus = 0u;

		/* Start recovery timer only when voltage is back OK */
		if (SMon_VfbL1 >= SMon_T30P50)
		{
			if (l1_uv_recovery_ts == 0u)
			{
				l1_uv_recovery_ts = SMon_MainCnt;
			}
			else
			{
				if (SMon_P_WaitTimeOVUV < (SMon_MainCnt - l1_uv_recovery_ts))
				{
					/* Valid recovery → clear fault */
					SMon_L1_UVStatus = 0u;
					SMon_CounterUVL1 = 0u;
					l1_uv_recovery_ts = 0u;

					if (0x2fu == Dem_GetDtcStatus(0x56u))
					{
						Dem_SetDtc(0x56u, 0x2eu);
					}
					else
					{
						// do nothing.
					}
				}
				else
				{
					// do nothing.
				}
			}
		}
		else
		{
			/* Still faulty → reset recovery timer */
			l1_uv_recovery_ts = 0u;
		}
	}
	else
	{
		l1_uv_recovery_ts = 0u;
	}

	if(pSMon_CmdStat != SMon_CmdStat)
	{
		pSMon_CmdStat = SMon_CmdStat;
	}
	else
	{
		/* Do nothing. */
	}

	if(pSMon_I2TError != SMon_I2TError)
	{
		pSMon_I2TError = SMon_I2TError;
	}
	else
	{
		/* Do nothing. */
	}

	if(pSMon_CLS_Failure != SMon_CLS_Failure)
	{
		pSMon_CLS_Failure = SMon_CLS_Failure;
	}
	else
	{
		/* Do nothing. */
	}
}

static void SMon_LoadSwitchingDiagnosis(void)
{
	if(1u == SMon_CLSFlag) // CLS ongoing
	{
		if(SMon_P_CLSTime - 20u <= (SMon_MainCnt - SMon_CLSCheckVoltage_Timestamp))
		{
			if(SMon_P_UV_CLS <= SMon_VfbL1) // voltage is rising, no error
			{
				SMon_CLS_Failure = 0u;

				if(0x2f == Dem_GetDtcStatus(0x55))
				{
					Dem_SetDtc(0x55, 0x2e);

				}
				else
				{
					/* Do nothing. */
				}
			}
			else
			{
				SMon_CLS_Failure = 1u;
				SMon_RequestPhysicalStatus = 0u;
				Dem_SetDtc(0x55, 0x2f);
			}
		}
		else
		{
			/* Do nothing. */
		}

		if(SMon_P_CLSTime - 14u <= (SMon_MainCnt - SMon_CLSCheckVoltage_Timestamp))
		{
			if((SMon_T30P50 - 1000u) <= SMon_VfbL1) // voltage is rising, no error
			{
				SMon_CLS_Failure = 0u;

				if(0x2f == Dem_GetDtcStatus(0x55))
				{
					Dem_SetDtc(0x55, 0x2e);
				}
				else
				{
					/* Do nothing. */
				}
			}
			else
			{
				SMon_CLS_Failure = 1u;
				SMon_RequestPhysicalStatus = 0u;
				Dem_SetDtc(0x55, 0x2f);
			}
		}
		else
		{
			/* Do nothing. */
		}
	}
	else if(2u == SMon_CLSFlag) // CLS is done
	{
		if(1u == SMon_SWState)
		{
			if(SMon_T30P50 <= SMon_VfbL1) // No UV on output
			{
				SMon_L1_UVStatus = 0u;
				SMon_CounterUVL1 = 0u; // reset counter
			}
			else
			{
				if(SMon_VfbL1 < SMon_T30P50)
				{
					if(0u == SMon_CounterUVL1) // "first call"
					{
						SMon_CounterUVL1 = SMon_MainCnt; // time-stamp
					}
					else
					{
						if(SMon_P_WaitTimeOVUV < (SMon_MainCnt - SMon_CounterUVL1)) // de-bounce for UV - 300ms
						{
							SMon_L1_UVStatus = 1u;
							SMon_RequestPhysicalStatus = 0u;
							Dem_SetDtc(0x56, 0x2f);

						}
						else
						{
							/* Do nothing. */
						}
					}
				}
				else
				{
					if(0x2f == Dem_GetDtcStatus(0x56))
					{
						Dem_SetDtc(0x56, 0x2e);
					}
					else
					{
						/* Do nothing. */
					}
				}
			}
		}
		else
		{
			/* Do nothing. */
		}

	}
	else
	{
		/* Do nothing. */
	}
}

static void SMon_LoadSwitchingLogic(void)
{
	static uint8_t localCPCFlag = 0u; // CPC status flag - off / on
	static uint32_t localCLSCounter = 0u; // time to wait with CLS active before changing CPC flag states

	htim1.Instance->CCR1 = 514u; // switch on CPC
	localCPCFlag = 2u; // CPC finished

	if(1u == SMon_RequestPhysicalStatus)
	{
		if(2u == localCPCFlag) // CPC finished
		{
			if(0u == SMon_CLSFlag) // CLS off
			{
				if(0u == localCLSCounter) // "first call"
				{
					localCLSCounter = SMon_MainCnt; // time-stamp
					SMon_CLSCheckVoltage_Timestamp = SMon_MainCnt;
					SMon_CLSFlag = 1u; // CLS ongoing
					HAL_GPIO_WritePin(ENL1CLS_GPIO_Port, ENL1CLS_Pin, 1u); // switch on CLS circuit
				}
				else
				{
					/* Do nothing. */
				}
			}
			else if(1u == SMon_CLSFlag) // CLS ongoing
			{
				if(SMon_P_CLSTime <= (SMon_MainCnt - localCLSCounter)) // de-bounce time based on parameter
				{
					localCLSCounter = 0u; // reset counter
					SMon_CLSFlag = 2u; // CLS finished
					HAL_GPIO_WritePin(ENL1CLS_GPIO_Port, ENL1CLS_Pin, 0u); // switch off CLS circuit
				}
				else if(SMon_P_CLSTime - 1u <= (SMon_MainCnt - localCLSCounter))
				{
					HAL_GPIO_WritePin(ENL1_GPIO_Port, ENL1_Pin, 1u); // switch on L1 circuit
				}
				else
				{
					/* Do nothing. */
				}
			}
			else
			{
				/* Do nothing. */
			}
		}
		else
		{
			/* Do nothing. */
		}
	}
	else if(0u == SMon_RequestPhysicalStatus)
	{
		localCPCFlag = 0u; // reset flag
		SMon_CLSFlag = 0u; // reset flag
		SMon_CounterUVL1 = 0u; // reset counter
		localCLSCounter = 0u; // reset counter
		SMon_CLSCheckVoltage_Timestamp = 0u;
		HAL_GPIO_WritePin(ENL1CLS_GPIO_Port, ENL1CLS_Pin, 0u); // switch off CLS
		HAL_GPIO_WritePin(ENL1_GPIO_Port, ENL1_Pin, 0u); // switch off L1
	}
	else
	{
		/* Do nothing. */
	}
}

static void SMon_LoadCurrentErrorState(void)
{
	SMon_ProcessLoadCurrentState();
	SMon_ProcessLoadErrorStatus();
	SMon_I2TAccumulation();
	SMon_ProcessShortToPlusTest();
}

static void SMon_LoadSwitchState(void)
{
	SMon_LoadSwitchingDiagnosis();
	SMon_LoadSwitchingLogic();
}

void SMon_main(void)
{
	SMon_ProcessEcuVoltageState();
	SMon_LoadCurrentErrorState();
	SMon_LoadSwitchState();
	SMon_BatteryData();

	SMon_MainCnt++;
}
