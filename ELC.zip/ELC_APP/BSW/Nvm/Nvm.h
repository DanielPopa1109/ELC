#ifndef NVM_H
#define NVM_H

#include <stdint.h>
#include "crc.h"
#include "adc.h"
#include "main.h"
#include <string.h>
#include "stdio.h"
#include <stdlib.h>

#define NVM_NO_BLOCKS               4U
#define NVM_SIZE_HEADER_BYTES       8U
#define NVM_PARAMFLASH_START_ADDRESS 0x08003800u
#define NVM_DTC_START_ADDRESS        0x0800F800u
#define NVM_DTC_END_ADDRESS          0x0800FFFFu
#define DFLASH_STARTING_ADDRESS      0x0800F800u
#define BYTES_TO_WORDS(x)  ((uint16_t)((x) / 4u))
#define NVM_LARGEST_BLOCK_SIZE sizeof(Dem_FF)


typedef struct
{
    uint8_t  blockId;
    uint16_t blockSize;
    uint8_t  padding1;
    uint32_t padding2;
} Nvm_Header_t;

typedef struct
{
    uint16_t blockSize;
    uint32_t blockAddress;
    uint16_t padding1;
} Nvm_NvStat_t;

typedef struct
{
    void*    data;
} Nvm_Block_t;

extern uint32_t Nvm_CurrentAddress;
extern Nvm_Header_t Nvm_HeaderArr[NVM_NO_BLOCKS];
extern Nvm_NvStat_t Nvm_NvStatArr[NVM_NO_BLOCKS];
extern Nvm_Header_t Nvm_HeaderArr_Default[NVM_NO_BLOCKS];
extern Nvm_NvStat_t Nvm_NvStatArr_Default[NVM_NO_BLOCKS];
extern Nvm_Block_t Nvm_BlockDataList[NVM_NO_BLOCKS];
extern Nvm_Block_t Nvm_RomDefaults_BlockDataList[NVM_NO_BLOCKS];
extern uint8_t Nvm_BlockIdListForWriteAll[NVM_NO_BLOCKS];
extern uint8_t Nvm_ParamFlashBlock[292u];

extern void Nvm_SectorSwitch(void);
extern void Nvm_WriteBlock(uint16_t blockId, void* data);
extern void Nvm_FindCurrentAddress(void);
extern void Nvm_ReadAll(void);
extern void Nvm_WriteAll(void);
extern uint32_t Nvm_GetPage(uint32_t Address);
extern void Nvm_FlashReadData(uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords);
extern uint32_t Nvm_FlashWriteData(uint32_t StartPageAddress, uint32_t *Data, uint16_t numberofwords);
extern uint32_t Nvm_Erase(void);
extern uint32_t Nvm_EraseParamflash(void);
extern void Nvm_InitParamFlash(void);

#endif /* NVM_H */
