#include "Nvm.h"
#include "Dem.h"
#include "EcuM.h"
#include "Dcm.h"
#include "SMon.h"

uint32_t Nvm_CurrentAddress;
Nvm_Header_t Nvm_HeaderArr[NVM_NO_BLOCKS];
Nvm_NvStat_t Nvm_NvStatArr[NVM_NO_BLOCKS];
uint8_t Nvm_BlockIdListForWriteAll[NVM_NO_BLOCKS] = {0u, 1u, 1u, 1u};
uint8_t Nvm_ParamFlashBlock[292u] = {0u};

Nvm_Header_t Nvm_HeaderArr_Default[NVM_NO_BLOCKS]=
{
		{0u, 0u, 0u, 0u}, // block 0 dummy not used
		{1u, sizeof(Dem_DTC_Stat), 0u, 0u},
		{2u, sizeof(Dem_FF), 0u, 0u},
		{3u, sizeof(SMon_Battery), 0u, 0u},
};

Nvm_NvStat_t Nvm_NvStatArr_Default[NVM_NO_BLOCKS] =
{
		{0u, 0u, 0u}, // block 0 dummy not used
		{sizeof(Dem_DTC_Stat), 0u, 0u,},
		{sizeof(Dem_FF), 0u, 0u},
		{sizeof(SMon_BatteryData_t), 0u, 0u},
};

Nvm_Block_t Nvm_BlockDataList[NVM_NO_BLOCKS] =
{
		{0u}, // block 0 dummy not used
		{&Dem_DTC_Stat[0u]},
		{&Dem_FF[0u].occurrenceCnt},
		{&SMon_Battery.Voltage_V},
};

Nvm_Block_t Nvm_RomDefaults_BlockDataList[NVM_NO_BLOCKS] =
{
		{0u}, // block 0 dummy not used
		{&Dem_DTC_Stat[0u]},
		{&Dem_FF[0u].occurrenceCnt},
		{&SMon_Battery.Voltage_V},
};

void Nvm_SectorSwitch(void);
void Nvm_WriteBlock(uint16_t blockId, void *data);
void Nvm_FindCurrentAddress();
void Nvm_ReadAll(void);
void Nvm_WriteAll(void);
uint32_t Nvm_GetPage(uint32_t Address);
void Nvm_FlashReadData(uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords);
uint32_t Nvm_FlashWriteData(uint32_t StartPageAddress, uint32_t *Data, uint16_t numberofwords);
uint32_t Nvm_Erase();
void Nvm_InitParamFlash(void);
uint32_t Nvm_EraseParamflash();
static uint32_t rd_u32(const uint8_t *p);
static float rd_f32(const uint8_t *p);

static uint32_t rd_u32(const uint8_t *p)
{
	return (uint32_t)p[0] |
			((uint32_t)p[1] << 8) |
			((uint32_t)p[2] << 16) |
			((uint32_t)p[3] << 24);
}

static float rd_f32(const uint8_t *p)
{
	uint32_t tmp = rd_u32(p);
	float f;
	memcpy(&f, &tmp, 4);
	return f;
}

void Nvm_InitParamFlash(void)
{
	Nvm_FlashReadData(NVM_PARAMFLASH_START_ADDRESS, (uint32_t*)Nvm_ParamFlashBlock, sizeof(Nvm_ParamFlashBlock) / 4u);

	if(0xAAu == Nvm_ParamFlashBlock[291u])
	{
		uint32_t idx = 0u;

		idx += 4; /* legacy slot kept to preserve param flash layout */
		idx += 4; /* unused legacy slot */
		SMon_P_DischargeTimeCycles        = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_NTC_PullUp_ResistorVale    = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_LongDischargeTimeCycles    = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_LowDisTimeCyc              = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_ClsFailureWaitTime         = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_LowVoltage                 = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_UV_KL30                    = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_OV_KL30                    = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_UV_CLS                     = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_Varef                      = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_ADC_MaxValue               = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_NTC_L1_TwoPointCalibration_ParamB = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_StatusVoltageL1Filter       = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_I2TDebounceTime             = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_Rtcntmax                    = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_CLSTime                     = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_WaitTimeOVUV                = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_I2TDecrementPercentFactor   = rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_NTC_L1_TwoPointCalibration_ParamA 	= rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattRestTimeTicks        			= rd_u32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_VFB_T30_TwoPointCalibration_ParamA = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_VFB_T30_TwoPointCalibration_ParamB = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_VFB_L1_TwoPointCalibration_ParamA  = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_VFB_L1_TwoPointCalibration_ParamB  = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_ISenseNominal                      = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_I2TRating                          = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_RoomTempKelvin                     = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_VoltsAt25                          = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_AvgSlope                           = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_RoomTemperature                    = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_Kelvin                             = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_AlphaFilter                        = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_AlphaFilterExtChIsense             = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_TwoPointCalib_ConvFacISense        = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_TwoPointCalib_NoLoad_ISense        = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_ExternalChargerThreshold           = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_NTCTemperatureMax                  = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_NTCTemperatureRelease              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattNominalCapacity_Ah      = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_BattMinSoC_pct              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattMaxSoC_pct              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_BattRestVoltDelta_V         = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattWeakVolt_V              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattDeepDischargeVolt_V     = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattCrankVolt_V             = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattAlphaVolt               = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattAlphaCurr               = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattAlphaRint               = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattChargeEfficiency        = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattOcvCorrectionGain       = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattSoHMin_pct              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattSoHMax_pct              = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattNominalRint_Ohm         = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattBadRint_Ohm             = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_BattCurrentDeadband_A = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		SMon_P_BattCurrentHys_A             = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattChargePathDeltaOn_V      = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattChargePathDeltaOff_V     = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		SMon_P_BattRintMinStep_A            = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
		idx += 4; /* unused legacy slot */
		idx += 4; /* unused legacy slot */
		idx += 4; /* unused legacy slot */
		SMon_P_BattRestDetectCurrent_A = rd_f32(&Nvm_ParamFlashBlock[idx]); idx += 4;
	}
	else
	{
		SMon_P_StatusVoltageL1Filter = 250u;
		SMon_P_I2TDebounceTime = 20u;
		SMon_P_Rtcntmax = 13u; // Retry Counter Parameter
		SMon_P_CLSTime = 22u; // CLS Duration Parameter
		SMon_P_WaitTimeOVUV = 80u; // OV UV De-bounce Time Parameter
		SMon_P_I2TDecrementPercentFactor = 85u; // Cooling Off Factor Parameter
		SMon_P_ClsFailureWaitTime = 190u; // Wait Time Between CLS Retries Parameter
		SMon_P_DischargeTimeCycles = 132000u; // ~50% Starting Voltage Discharge Time Parameter
		SMon_P_LowVoltage = 1200u; // 5TAU / Maximum Discharge Voltage Threshold Parameter
		SMon_P_UV_KL30 = 6900u; // UV KL30 TH Parameter
		SMon_P_OV_KL30 = 17200u; // OV KL30 TH Parameter
		SMon_P_UV_CLS = 700u;
		SMon_P_Varef = 3300u;
		SMon_P_ADC_MaxValue = 4095u;
		SMon_P_NTC_PullUp_ResistorVale = 91000u;
		SMon_P_LongDischargeTimeCycles = 564000u; // Maximum Discharge Time Parameter
		SMon_P_LowDisTimeCyc = 229600; // 2TAU Discharge Time Parameter
		SMon_P_VFB_T30_TwoPointCalibration_ParamA = 8.16f;
		SMon_P_VFB_T30_TwoPointCalibration_ParamB = 21.93f;
		SMon_P_VFB_L1_TwoPointCalibration_ParamA = 8.13f;
		SMon_P_VFB_L1_TwoPointCalibration_ParamB = 8.13f;
		SMon_P_NTC_L1_TwoPointCalibration_ParamA = 12332u; // R0_cal in ohms
		SMon_P_BattRestTimeTicks        = 200u;   /* tune to scheduler tick */
		SMon_P_NTC_L1_TwoPointCalibration_ParamB = 4984u;  // Beta_cal in K
		SMon_P_ISenseNominal = 28.000f; // Nominal Current Parameter
		SMon_P_I2TRating = 1176.0f; // I2T Rating Parameter
		SMon_P_RoomTempKelvin = 297.15f;
		SMon_P_VoltsAt25 = 1430.0f;
		SMon_P_AvgSlope = 4.30f;
		SMon_P_RoomTemperature = 25.0f;
		SMon_P_Kelvin = 273.15f;
		SMon_P_AlphaFilter = 0.90f;
		SMon_P_AlphaFilterExtChIsense = 0.0001f;
		SMon_P_TwoPointCalib_ConvFacISense = 15.91f;
		SMon_P_TwoPointCalib_NoLoad_ISense = 613.2f;
		SMon_P_ExternalChargerThreshold = -1.0f;
		SMon_P_NTCTemperatureMax = 90.0f;
		SMon_P_NTCTemperatureRelease = 80.0f;
		SMon_P_BattNominalCapacity_Ah      = 77.0f;
		SMon_P_BattMinSoC_pct              = 1.0f;
		SMon_P_BattMaxSoC_pct              = 100.0f;
		SMon_P_BattRestVoltDelta_V         = 0.02f;
		SMon_P_BattWeakVolt_V              = 11.80f;
		SMon_P_BattDeepDischargeVolt_V     = 11.10f;
		SMon_P_BattCrankVolt_V             = 9.60f;
		SMon_P_BattAlphaVolt               = 0.02f;
		SMon_P_BattAlphaCurr               = 0.05f;
		SMon_P_BattAlphaRint               = 0.10f;
		SMon_P_BattChargeEfficiency        = 0.90f;
		SMon_P_BattOcvCorrectionGain       = 0.20f;
		SMon_P_BattSoHMin_pct              = 1.0f;
		SMon_P_BattSoHMax_pct              = 100.0f;
		SMon_P_BattNominalRint_Ohm         = 0.015f;
		SMon_P_BattBadRint_Ohm             = 0.060f;
		SMon_P_BattCurrentDeadband_A = 1.0f;
		SMon_P_BattCurrentHys_A            = 0.30f;
		SMon_P_BattChargePathDeltaOn_V     = 0.25f;
		SMon_P_BattChargePathDeltaOff_V    = 0.10f;
		SMon_P_BattRintMinStep_A           = 0.20f;
		SMon_P_BattRestDetectCurrent_A = 0.30f;

		uint32_t idx = 0u;

#define COPY_TO_BUF(val)                     \
		do \
		{                                        \
			memcpy(&Nvm_ParamFlashBlock[idx],        \
					&(val),                          \
					sizeof(val));                    \
					idx += sizeof(val);                     \
		} while(0)

		idx += 4; /* legacy slot kept to preserve param flash layout */
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_DischargeTimeCycles);
		COPY_TO_BUF(SMon_P_NTC_PullUp_ResistorVale);
		COPY_TO_BUF(SMon_P_LongDischargeTimeCycles);
		COPY_TO_BUF(SMon_P_LowDisTimeCyc);
		COPY_TO_BUF(SMon_P_ClsFailureWaitTime);
		COPY_TO_BUF(SMon_P_LowVoltage);
		COPY_TO_BUF(SMon_P_UV_KL30);
		COPY_TO_BUF(SMon_P_OV_KL30);
		COPY_TO_BUF(SMon_P_UV_CLS);
		COPY_TO_BUF(SMon_P_Varef);
		COPY_TO_BUF(SMon_P_ADC_MaxValue);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_NTC_L1_TwoPointCalibration_ParamB);
		COPY_TO_BUF(SMon_P_StatusVoltageL1Filter);
		COPY_TO_BUF(SMon_P_I2TDebounceTime);
		COPY_TO_BUF(SMon_P_Rtcntmax);
		COPY_TO_BUF(SMon_P_CLSTime);
		COPY_TO_BUF(SMon_P_WaitTimeOVUV);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_I2TDecrementPercentFactor);
		COPY_TO_BUF(SMon_P_NTC_L1_TwoPointCalibration_ParamA);
		COPY_TO_BUF(SMon_P_BattRestTimeTicks);
		COPY_TO_BUF(SMon_P_VFB_T30_TwoPointCalibration_ParamA);
		COPY_TO_BUF(SMon_P_VFB_T30_TwoPointCalibration_ParamB);
		COPY_TO_BUF(SMon_P_VFB_L1_TwoPointCalibration_ParamA);
		COPY_TO_BUF(SMon_P_VFB_L1_TwoPointCalibration_ParamB);
		COPY_TO_BUF(SMon_P_ISenseNominal);
		COPY_TO_BUF(SMon_P_I2TRating);
		COPY_TO_BUF(SMon_P_RoomTempKelvin);
		COPY_TO_BUF(SMon_P_VoltsAt25);
		COPY_TO_BUF(SMon_P_AvgSlope);
		COPY_TO_BUF(SMon_P_RoomTemperature);
		COPY_TO_BUF(SMon_P_Kelvin);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_AlphaFilter);
		COPY_TO_BUF(SMon_P_AlphaFilterExtChIsense);
		COPY_TO_BUF(SMon_P_TwoPointCalib_ConvFacISense);
		COPY_TO_BUF(SMon_P_TwoPointCalib_NoLoad_ISense);
		COPY_TO_BUF(SMon_P_ExternalChargerThreshold);
		COPY_TO_BUF(SMon_P_NTCTemperatureMax);
		COPY_TO_BUF(SMon_P_NTCTemperatureRelease);
		COPY_TO_BUF(SMon_P_BattNominalCapacity_Ah);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_BattMinSoC_pct);
		COPY_TO_BUF(SMon_P_BattMaxSoC_pct);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_BattRestVoltDelta_V);
		COPY_TO_BUF(SMon_P_BattWeakVolt_V);
		COPY_TO_BUF(SMon_P_BattDeepDischargeVolt_V);
		COPY_TO_BUF(SMon_P_BattCrankVolt_V);
		COPY_TO_BUF(SMon_P_BattAlphaVolt);
		COPY_TO_BUF(SMon_P_BattAlphaCurr);
		COPY_TO_BUF(SMon_P_BattAlphaRint);
		COPY_TO_BUF(SMon_P_BattChargeEfficiency);
		COPY_TO_BUF(SMon_P_BattOcvCorrectionGain);
		COPY_TO_BUF(SMon_P_BattSoHMin_pct);
		COPY_TO_BUF(SMon_P_BattSoHMax_pct);
		COPY_TO_BUF(SMon_P_BattNominalRint_Ohm);
		COPY_TO_BUF(SMon_P_BattBadRint_Ohm);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_BattCurrentDeadband_A);
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_BattCurrentHys_A);
		COPY_TO_BUF(SMon_P_BattChargePathDeltaOn_V);
		COPY_TO_BUF(SMon_P_BattChargePathDeltaOff_V);
		COPY_TO_BUF(SMon_P_BattRintMinStep_A);
		idx += 4; /* unused legacy slot */
		idx += 4; /* unused legacy slot */
		idx += 4; /* unused legacy slot */
		COPY_TO_BUF(SMon_P_BattRestDetectCurrent_A);

		Nvm_ParamFlashBlock[291u] = 0xAAu;
		Nvm_ParamFlashBlock[290u] = 0x21u;
		Nvm_EraseParamflash();
		Nvm_FlashWriteData(NVM_PARAMFLASH_START_ADDRESS, (uint32_t*)Nvm_ParamFlashBlock, sizeof(Nvm_ParamFlashBlock) / 4u);

#undef COPY_TO_BUF
	}
}

void Nvm_SectorSwitch(void)
{
	__disable_irq();

	uint32_t startPattern[2u] = {0u, 0u};

	Nvm_Erase();

	Nvm_CurrentAddress = DFLASH_STARTING_ADDRESS;
	startPattern[0u] = 0xB6B6B6B6u;
	startPattern[1u] = 0xB6B6B6B6u;

	Nvm_FlashWriteData(Nvm_CurrentAddress, startPattern, 2u);

	Nvm_CurrentAddress += 8u;

	for(uint8_t i = 1u; i < NVM_NO_BLOCKS; i++)
	{
		Nvm_WriteBlock(i, Nvm_BlockDataList[i].data);
	}
}

void Nvm_WriteBlock(uint16_t blockId, void *data)
{
	/* Parameter validation */
	if ((blockId >= NVM_NO_BLOCKS) ||
			(blockId == 0u) || /* block 0 is reserved */
			(data == NULL))
	{
		return;
	}
	else
	{
		// do nothing.
	}

	__disable_irq();

	uint32_t address = Nvm_CurrentAddress;
	uint32_t crc;
	uint32_t crcPadded[2] = {0u, 0xFFFFFFFFu};
	uint32_t localMaxAddress = NVM_DTC_END_ADDRESS;
	uint16_t sizeWords = (uint16_t)(Nvm_NvStatArr[blockId].blockSize / 4u);

	crc = HAL_CRC_Calculate(&hcrc, data, sizeWords);

	if ((address + NVM_SIZE_HEADER_BYTES +
			Nvm_NvStatArr[blockId].blockSize + 8u) < localMaxAddress)
	{
		/* header */
		Nvm_FlashWriteData(address,
				(uint32_t*)&Nvm_HeaderArr[blockId],
				BYTES_TO_WORDS(NVM_SIZE_HEADER_BYTES));
		address += NVM_SIZE_HEADER_BYTES;

		Nvm_NvStatArr[blockId].blockAddress = address;

		/* data */
		Nvm_FlashWriteData(address, data, sizeWords);
		address += Nvm_NvStatArr[blockId].blockSize;

		/* crc + padding (8 bytes = 2 words) */
		crcPadded[0u] = crc;
		Nvm_FlashWriteData(address, crcPadded, 2u);
		address += 8u;

		Nvm_CurrentAddress = address;
	}
	else
	{
		/* page full -> compact (erase + rewrite all) */
		Nvm_SectorSwitch();

		address = Nvm_CurrentAddress;

		Nvm_FlashWriteData(address,
				(uint32_t*)&Nvm_HeaderArr[blockId],
				BYTES_TO_WORDS(NVM_SIZE_HEADER_BYTES));
		address += NVM_SIZE_HEADER_BYTES;

		Nvm_NvStatArr[blockId].blockAddress = address;

		Nvm_FlashWriteData(address, data, sizeWords);
		address += Nvm_NvStatArr[blockId].blockSize;

		crcPadded[0u] = crc;
		Nvm_FlashWriteData(address, crcPadded, 2u);
		address += 8u;

		Nvm_CurrentAddress = address;
	}

	__enable_irq();
}

void Nvm_FindCurrentAddress()
{
	__disable_irq();

	uint32_t localAddress = Nvm_CurrentAddress;
	uint32_t keepOldLocalAddress = localAddress;
	uint32_t startPattern[2u] = {0u, 0u};
	uint32_t localMaxAddress = NVM_DTC_END_ADDRESS - NVM_LARGEST_BLOCK_SIZE;
	Nvm_Header_t localHeader;
	uint8_t localBlockId;

	if (0u == localAddress)
	{
		localAddress = DFLASH_STARTING_ADDRESS;
		Nvm_CurrentAddress = localAddress;
		keepOldLocalAddress = localAddress;
	}

	if (DFLASH_STARTING_ADDRESS == localAddress)
	{
		/* Read start pattern (2 words) */
		Nvm_FlashReadData(localAddress, startPattern, 2u);

		if (0xB6B6B6B6u == startPattern[0u] &&
				0xB6B6B6B6u == startPattern[1u])
		{
			localAddress += 8u;

			while ((localAddress + NVM_SIZE_HEADER_BYTES + 8u) < localMaxAddress)
			{
				Nvm_FlashReadData(localAddress,
						(uint32_t*)&localHeader,
						BYTES_TO_WORDS(NVM_SIZE_HEADER_BYTES));

				localBlockId = localHeader.blockId;

				if (0xFFu != localBlockId && NVM_NO_BLOCKS > localBlockId)
				{
					if (localHeader.blockId  == Nvm_HeaderArr_Default[localBlockId].blockId &&
							localHeader.blockSize == Nvm_HeaderArr_Default[localBlockId].blockSize)
					{
						Nvm_HeaderArr[localBlockId].blockId    = localHeader.blockId;
						Nvm_HeaderArr[localBlockId].blockSize  = localHeader.blockSize;
						Nvm_NvStatArr[localBlockId].blockSize  = localHeader.blockSize;
						Nvm_NvStatArr[localBlockId].blockAddress =
								localAddress + NVM_SIZE_HEADER_BYTES;

						/* jump over header + data + crc(8) */
						localAddress += NVM_SIZE_HEADER_BYTES +
								localHeader.blockSize + 8u;

						Nvm_CurrentAddress   = localAddress;
						keepOldLocalAddress  = localAddress;
					}
					else
					{
						localAddress += NVM_SIZE_HEADER_BYTES;
						Nvm_CurrentAddress = localAddress;
					}
				}
				else
				{
					/* uninitialized header -> end of used area */
					break;
				}
			}
		}
		else if (0xFFFFFFFFu != startPattern[0u] ||
				0xFFFFFFFFu != startPattern[1u])
		{
			/* garbage -> erase + reinit */
			Nvm_Erase();

			startPattern[0u] = 0xB6B6B6B6u;
			startPattern[1u] = 0xB6B6B6B6u;

			Nvm_FlashWriteData(localAddress, startPattern, 2u);

			localAddress       += 8u;
			Nvm_CurrentAddress  = localAddress;
			keepOldLocalAddress = localAddress;
		}
		else
		{
			/* fresh page */
			startPattern[0u] = 0xB6B6B6B6u;
			startPattern[1u] = 0xB6B6B6B6u;

			Nvm_FlashWriteData(localAddress, startPattern, 2u);

			localAddress       += 8u;
			Nvm_CurrentAddress  = localAddress;
			keepOldLocalAddress = localAddress;
		}
	}

	Nvm_CurrentAddress = keepOldLocalAddress;
}

void Nvm_ReadAll(void)
{
	__disable_irq();

	uint32_t localCrc[2] = {0u};
	uint32_t compareCrc;
	uint32_t crcAddress;

	Nvm_FindCurrentAddress();

	for (uint8_t i = 1u; i < NVM_NO_BLOCKS; i++)
	{
		if ((Nvm_HeaderArr[i].blockId   != 0xFFu) &&
				(Nvm_HeaderArr[i].blockId   != 0u)    &&
				(Nvm_HeaderArr[i].blockSize != 0xFFu) &&
				(Nvm_HeaderArr[i].blockSize != 0u))
		{
			/* read data */
			Nvm_FlashReadData(Nvm_NvStatArr[i].blockAddress,
					(uint32_t*)Nvm_BlockDataList[i].data,
					(uint16_t)(Nvm_NvStatArr[i].blockSize / 4u));

			crcAddress = Nvm_NvStatArr[i].blockAddress +
					Nvm_NvStatArr[i].blockSize;

			/* read crc (2 words) */
			Nvm_FlashReadData(crcAddress, localCrc, 2u);

			compareCrc = HAL_CRC_Calculate(&hcrc,
					(uint32_t*)Nvm_BlockDataList[i].data,
					(uint32_t)(Nvm_NvStatArr[i].blockSize / 4u));

			if (compareCrc != localCrc[0u])
			{
				/* CRC fail -> load defaults into RAM + write back */
				memcpy((void*)Nvm_BlockDataList[i].data,
						(const void*)Nvm_RomDefaults_BlockDataList[i].data,
						Nvm_NvStatArr[i].blockSize);

				Nvm_WriteBlock(i, Nvm_BlockDataList[i].data);
			}
		}
		else
		{
			/* header invalid -> use defaults */
			memcpy(&Nvm_HeaderArr[i],
					&Nvm_HeaderArr_Default[i],
					sizeof(Nvm_HeaderArr[i]));

			memcpy(&Nvm_NvStatArr[i],
					&Nvm_NvStatArr_Default[i],
					sizeof(Nvm_NvStatArr[i]));

			memcpy((void*)Nvm_BlockDataList[i].data,
					(const void*)Nvm_RomDefaults_BlockDataList[i].data,
					Nvm_NvStatArr[i].blockSize);

			Nvm_WriteBlock(i, Nvm_BlockDataList[i].data);
		}
	}

	__enable_irq();
}

void Nvm_WriteAll(void)
{
	__disable_irq();

	for(uint8_t i = 0u; i < NVM_NO_BLOCKS; i++)
	{
		if(1u == Nvm_BlockIdListForWriteAll[i])
		{
			Nvm_WriteBlock(i, Nvm_BlockDataList[i].data);
		}
		else
		{
			/* Do nothing. */
		}
	}

	__enable_irq();
}

uint32_t Nvm_GetPage(uint32_t Address)
{
	for (uint8_t indx=0; indx < 128; indx++)
	{
		if((Address < (0x08000000 + (FLASH_PAGE_SIZE *(indx + 1))) ) && (Address >= (0x08000000 + FLASH_PAGE_SIZE * indx)))
		{
			return (0x08000000 + FLASH_PAGE_SIZE * indx);
		}
		else
		{
			/* Do nothing. */
		}
	}

	return 0;
}

uint32_t Nvm_EraseParamflash()
{
	static FLASH_EraseInitTypeDef EraseInitStruct;

	uint32_t PAGEError;

	uint32_t StartPage = Nvm_GetPage(NVM_PARAMFLASH_START_ADDRESS);

	HAL_FLASH_Unlock();

	EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = StartPage;
	EraseInitStruct.NbPages     = 1;

	if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
	{
		return HAL_FLASH_GetError ();
	}
	else
	{
		/* Do nothing. */
	}

	HAL_FLASH_Lock();

	return 0;
}

uint32_t Nvm_Erase()
{
	static FLASH_EraseInitTypeDef EraseInitStruct;

	uint32_t PAGEError;

	uint32_t StartPage = Nvm_GetPage(NVM_DTC_START_ADDRESS);

	HAL_FLASH_Unlock();

	EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = StartPage;
	EraseInitStruct.NbPages     = 2;

	if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
	{
		return HAL_FLASH_GetError ();
	}
	else
	{
		/* Do nothing. */
	}

	HAL_FLASH_Lock();

	return 0;
}

uint32_t Nvm_FlashWriteData(uint32_t addr, uint32_t *data, uint16_t wordCount)
{
	uint32_t err;

	HAL_FLASH_Unlock();

	for (uint16_t i = 0; i < wordCount; i++)
	{
		if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, data[i]) != HAL_OK)
		{
			err = HAL_FLASH_GetError();

			HAL_FLASH_Lock();

			return err;
		}
		else
		{
			/* Do nothing. */
		}

		addr += 4u;
	}

	HAL_FLASH_Lock();

	return 0u;
}

void Nvm_FlashReadData(uint32_t addr, uint32_t *rxBuf, uint16_t wordCount)
{
	for (uint16_t i = 0; i < wordCount; i++)
	{
		rxBuf[i] = *(__IO uint32_t *)(addr + (i * 4u));
	}
}
