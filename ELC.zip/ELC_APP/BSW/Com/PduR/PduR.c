#include "PduR.h"
#include "../CanIf/CanIf.h"
#include "../Com/Com.h"

static uint8_t initialized;

void PduR_Init(void) { initialized = 1u; }

int PduR_ComTransmit(uint8_t txPduId, const uint8_t *data, uint8_t len)
{
    if ((initialized == 0u) || (txPduId != PDUR_TX_LOADSTATUS)) return -1;
    return CanIf_Transmit(CANIF_TX_LOADSTATUS, data, len);
}

int PduR_ComTransmitTelemetry(uint16_t canId, const uint8_t *data, uint8_t len)
{
    if (initialized == 0u) return -1;
    return CanIf_TransmitTelemetry(canId, data, len);
}

void PduR_CanIfRxIndication(uint8_t rxPduId, const uint8_t *data, uint8_t len)
{
    if (initialized == 0u) return;
    if (rxPduId == PDUR_RX_LOADREQUEST)
        Com_RxIndication(COM_RX_LOADREQUEST, data, len);
    else if (rxPduId == PDUR_RX_VEHICLESTATE)
        Com_RxIndication(COM_RX_VEHICLESTATE, data, len);
}
