#ifndef ELC_BSW_CANIF_H
#define ELC_BSW_CANIF_H

#include <stdint.h>

enum { CANIF_TX_LOADSTATUS = 0u, CANIF_RX_LOADREQUEST = 0u,
       CANIF_RX_VEHICLESTATE = 1u };

void CanIf_Init(void);
void CanIf_SetApplicationTxEnabled(uint8_t enabled);
int CanIf_Transmit(uint8_t txPduId, const uint8_t *data, uint8_t len);
int CanIf_TransmitTelemetry(uint16_t canId, const uint8_t *data, uint8_t len);
void CanIf_RxIndication(uint16_t canId, const uint8_t *data, uint8_t len);

#endif
