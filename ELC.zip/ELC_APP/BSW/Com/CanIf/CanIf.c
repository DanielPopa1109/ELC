#include "CanIf.h"
#include "../Can/Can.h"
#include "../PduR/PduR.h"
#include "../CanNm/CanNm.h"

static uint8_t initialized;
static uint8_t applicationTxEnabled;

void CanIf_Init(void) { applicationTxEnabled = 0u; initialized = 1u; }
void CanIf_SetApplicationTxEnabled(uint8_t enabled)
{
    applicationTxEnabled = enabled ? 1u : 0u;
}

int CanIf_Transmit(uint8_t txPduId, const uint8_t *data, uint8_t len)
{
    if ((initialized == 0u) || (applicationTxEnabled == 0u) ||
        (txPduId != CANIF_TX_LOADSTATUS) || (len != 1u)) return -1;
    return Can_Write(0x051u, data, len);
}

int CanIf_TransmitTelemetry(uint16_t canId, const uint8_t *data, uint8_t len)
{
    uint8_t expectedLen;
    if ((initialized == 0u) || (applicationTxEnabled == 0u) ||
        (data == 0) || (canId < 0x6EEu) || (canId > 0x6F7u)) return -1;
    expectedLen = (canId == 0x6F0u) ? 4u :
                  (canId == 0x6F7u) ? 1u : 8u;
    if (len != expectedLen) return -1;
    return Can_Write(canId, data, len);
}

void CanIf_RxIndication(uint16_t canId, const uint8_t *data, uint8_t len)
{
    if ((initialized == 0u) || (data == 0) || (len > 8u)) return;
    if (canId == 0x050u)
        PduR_CanIfRxIndication(CANIF_RX_LOADREQUEST, data, len);
    else if (canId == 0x3A0u)
        PduR_CanIfRxIndication(CANIF_RX_VEHICLESTATE, data, len);
    else if (canId == 0x3FFu)
        CanNm_RxIndication(data, len);
}
