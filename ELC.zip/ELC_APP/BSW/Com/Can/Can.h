#ifndef ELC_BSW_CAN_H
#define ELC_BSW_CAN_H

#include <stdint.h>

/* bxCAN is initialized by MX_CAN_Init. This module owns BSW TX submission. */
int Can_Write(uint16_t canId, const uint8_t *data, uint8_t dlc);
uint8_t Can_IsControllerOnline(void);

#endif
