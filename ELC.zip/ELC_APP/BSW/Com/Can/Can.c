#include "Can.h"
#include "../../../Inc/can.h"

uint8_t Can_IsControllerOnline(void)
{
    if (HAL_CAN_GetState(&hcan) != HAL_CAN_STATE_LISTENING) return 0u;
    if ((hcan.Instance->ESR & CAN_ESR_BOFF) != 0u) return 0u;
    return 1u;
}

int Can_Write(uint16_t canId, const uint8_t *data, uint8_t dlc)
{
    CAN_TxHeaderTypeDef header = {0};
    uint32_t mailbox = 0u;
    if ((data == 0) || (canId > 0x7FFu) || (dlc > 8u)) return -1;
    if (Can_IsControllerOnline() == 0u) return -1;
    header.StdId = canId;
    header.IDE = CAN_ID_STD;
    header.RTR = CAN_RTR_DATA;
    header.DLC = dlc;
    return (HAL_CAN_AddTxMessage(&hcan, &header, (uint8_t *)data, &mailbox) == HAL_OK) ? 0 : -1;
}
