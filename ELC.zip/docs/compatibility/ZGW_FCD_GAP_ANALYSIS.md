# ZGW and FCD gap analysis

## Source facts

ZGW is an AURIX TC3xx gateway. Its `ParallelFlashSwc` routes downstream requests by extended diagnostic address; source maps ELC address `0x58` to a CAN target. ZGW `CanTp.c` uses extended addressing; `ParallelFlashSwc` calls `CanTp_TransmitExtendedAddress` and puts the target address in the first CAN data byte. The ZGW classic physical CAN PDU uses request ID `0x710`; FCD/ZGW route metadata does not transform that automatically into ELC's IDs. ZGW documentation specifies DoIP tester/client to gateway at `192.168.1.10:13400`, logical addresses tester `0x0710` and gateway `0x1001`; routed DoIP UDS adds a route byte at the gateway boundary.

FCD `Scripts/FCD/FCD.pyw` uses ELC extended address `0x58`; checked-in `fcd_settings.json` marks ELC `Simulated`, selected=false. FCD live flash sequence uses `31 01 0200 02` to select FBL and `31 01 0155` to enter RAM updater; generic erase RID is `0x0001` with 4-byte big-endian address/size options, then `34 00 44`, `36` starting BSC 1 and wrapping, `37` (optionally appending CRC32), optional separate CRC RID `0x0002`, and `11 01`. Constants appear near FCD.pyw lines 948–964; sequence is `_execute_payload`.

ELC APP and FBL source still filter standard ID `0x702` and respond on request ID + 1 (`0x703`). They decode ISO-TP PCI from data byte 0; neither has a target-address byte before PCI. Thus current ZGW classic routing presents a CAN-ID mismatch (`0x710` vs `0x702`) and extended-address framing mismatch (target byte `0x58` vs ELC PCI at byte 0). A target-specific ZGW/CanTp mapping or ECU-side compatibility change is required; source does not show such a bridge. `ParallelFlashSwc.c` currently sets `PARALLELFLASHSWC_FORWARD_ASSUME_CAN_FC` true and records synthetic TX acknowledgments; those do not prove an ELC response. Resident erase RIDs are `0004/0005`, RAM erase RID `0006`, resident RAM entry `0007`; legacy CRC RID is `0000` with a four-byte little-endian CRC. The new ELC range/BSC/CF checks and big-endian TransferExit CRC support close some target-side gaps, but FCD's erase `0001`, entry `0155`, select `0200`, and optional CRC `0002` remain unmatched.

## Consequence

An ELC node entry in ZGW/FCD does not prove end-to-end support. Current FCD live target sequence and ELC checked-in FBL RIDs do not match. Even matching RID constants would not solve payload-length/CRC endian, direct CAN vs gateway TP, unvalidated DCM session behavior, response timing or reset/re-entry semantics. A real target descriptor, compatible ELC protocol, ZGW route/PDU configuration, correct HEX address segments and bench trace are required.

Review ZGW `docs/compatibility/DIAGNOSTIC_CONTRACTS.md`, `FLASHING_CONTRACTS.md`; FCD `_execute_payload`; ELC FBL parser before migration.

## F93 comparison

F93's documented DMU FBL also uses `0x702/0x703`, but its active design is simpler and does not implement ISO-TP segmentation. ELC's segmented protocol and linked RAM FBL updater are valuable architecture references; they do not make ELC's RIDs or gateway path compatible. See [F93 bootloader docs](../../../F93/docs/bootloader/INDEX.md) for the source-level comparison and verify both repositories' implementation before reuse.
