# FBL updater source trace

## Application image path

FBL startup in `main()` initializes hardware, clears `.ncr` SRAM on POR, and chooses programming state from retained state/reset counter. Otherwise it reads the first APP word: when it is not erased, it loads the retained session status; if not programming, it calls `FBL_JumpToAppl`. Diagnostic `10 02` selects programming state. The parser's `31 01 0004` erases APP pages, `34` captures requested address/size, `36` buffers bytes and writes little-endian 32-bit words via HAL, and `31 01 0000` flushes tail bytes, computes reflected CRC-32 (poly `0xEDB88320`, init/final XOR all ones) over requested range, compares tester CRC and stores calculated CRC at `0x0800F7FC`. `37` only sends `77`; it does not finalize/validate. `11 01` replies then resets.

## FBL image path

FCD/source sequence targets routine `0x0200` to select FBL (`ACTIVE_SW_BLOCK_FBL=0x02`) and `0x0155` to enter RAM updater, then generic erase RID `0x0001` with big-endian address/size, `34/36/37`, optional CRC, then reset. The ELC RAM parser instead implements erase RID `0x0006`, CRC RID `0x0000`, and has no `0x0155` handler. The resident parser shown in this tree uses erase RIDs `0x0004/0x0005`, CRC RID `0x0000`, and `0x0007` to set `g_run_ram_updater`. Verify which deployed FBL image is actually present before using either sequence.

## Critical limitations

No security access; address/size validation is missing on resident `34`; TransferData sequence/length checks are absent; low-level write/erase return status is ignored by request handlers; app validity is not based on stored CRC at boot. RAM range check uses 32-bit `addr + size`, so overflow handling also needs explicit hardening. See [protocol](PROGRAMMING_PROTOCOL.md) and [recovery](STATE_MACHINE_AND_RECOVERY.md).
