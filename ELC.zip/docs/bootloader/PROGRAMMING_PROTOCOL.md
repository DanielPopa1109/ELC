# Programming protocol

## Transport

FBL generated CAN config receives standard ID `0x702`, transmits `0x703`; classic CAN, ISO-TP SF/FF/CF RX and FC TX. Resident parser advertises FC BS=0, STmin=5 ms; RX buffer is 4095 bytes. RAM parser buffer is 576 bytes and FC uses BS=0/STmin=5. Neither parser checks CF sequence numbers despite maintaining an SN variable. TX responses are emitted as single frames only (at most 7 UDS bytes), so larger responses are truncated/unsupported.

## Services

| Service | Resident FBL | RAM updater |
|---|---|---|
| `10 02` | enter programming state | retain state=2 |
| `31 01 0004` | erase APP | not implemented |
| `31 01 0005` | erase parameter page | not implemented |
| `31 01 0006` | not implemented | erase FBL range |
| `31 01 0007` | start RAM updater | not implemented in RAM parser |
| `34 00 44 addr size` | stores fields, no range guard | requires 4-byte address, positive size within FBL |
| `36 BSC data` | word buffers/write | word buffers/write |
| `37` | positive response only | positive response only |
| `31 01 0000 CRC32` | flush + CRC compare; persist CRC word | flush + CRC compare |
| `11 01` | reset | reset |

CRC parameter bytes are little-endian in legacy `31 01 0000`, despite FCD helper packing addresses/sizes in big-endian for `34`. Both parsers now also accept `37` followed by a four-byte big-endian CRC32 (FCD's default). The resident parser reserves `0x0800F7FC..0x0800F7FF` for its stored application CRC; `RequestDownload` must start on a four-byte boundary and end before that word. The RAM parser requires a four-byte-aligned start within `0x08000000..0x080037FF`. Both reject out-of-sequence BSC, excess bytes, malformed download format, and ISO-TP CF sequence errors. These are source changes without a current STM32 build or bench validation.

Current FCD sends `31 01 0200 02` to select FBL, `31 01 0155` to enter the RAM updater, and generic erase `31 01 0001 addr_be32 size_be32`. FCD's separate CRC routine is RID `0x0002` with address/size/CRC parameters; its default TransferExit CRC appends four bytes to `37`. The TransferExit CRC form is now handled, but entry, selection, erase and separate CRC RIDs remain incompatible: ELC uses entry RID `0x0007` resident / no entry RID in the RAM parser, erase `0x0004` resident or `0x0006` RAM, and legacy CRC RID `0x0000`. See [compatibility gap](../compatibility/ZGW_FCD_GAP_ANALYSIS.md).
