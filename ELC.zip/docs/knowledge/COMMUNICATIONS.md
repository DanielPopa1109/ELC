# Communications

ELC application and FBL use STM32 bxCAN CAN1, standard 11-bit CAN frames and classic CAN. They do not implement CAN FD or LIN in the reviewed source.

## CAN configuration

APP `Src/can.c`: prescaler 6, SJW 1 TQ, BS1 8 TQ, BS2 3 TQ, time-triggered mode enabled, FIFO locked and transmit FIFO priority enabled. Filters include IDs `0x702` routed to FIFO1 and `0x050`, `0x3FF`, `0x7C0`, `0x097`, `0x202`, `0x6D0` to FIFO0. FBL `Core/Src/can.c`: same controller/pins, prescaler 6, SJW 1, BS1 5, BS2 6, auto bus-off/wakeup/retransmit enabled, RX filter `0x702` FIFO0. Clock and transceiver timing are needed to derive bit rate.

## Application messages and diagnostics

`CanH_MainFunction` sends ELC status on ID `0x051` and battery/status frames including `0x6F1..0x6F4`; DTC broadcast uses `0x7FE`. The current encoder sends a one-byte `LoadStatus` with bit 0 from `SMon_L1ST`, matching ZGW `DB/ZGW_CAN_3.dbc` and `BSW/Com/Com.c` (RX signal bit 0, length 1). It sends every 100 nominal 5 ms QM_BSW activations (500 ms) or on change, below ZGW's configured 1005 ms receive deadline. It receives ZGW `LoadRequest` ID `0x050`, DLC 2: byte 0 contains alive bits 0..3, data ID bits 4..6, and request bit 7; byte 1 is the low byte of ZGW's reflected CRC32 over `[alive, request, dataId]`. The app requires data ID 7 and a matching CRC before applying the command; timeout clears `SMon_CmdStat`. ZGW source: `APP/GatewaySwc/GatewaySwc.c::GatewaySwc_GenerateCanOutputs`, `BSW/Com/Com.c`, `BSW/Com/CanIf/CanIf.c`. This is source-level compatibility, not a captured bus result. Other ELC messages still require signal and period validation.

APP filters diagnostic request ID `0x702` to FIFO1; FBL filters the same ID to FIFO0. Both use request ID + 1 (`0x703`) for replies; ISO-TP PCI is the first payload byte. FBL uses ISO-TP over classic CAN and 5-ms STmin flow control in the flash-resident receiver. Current ZGW classic CanTp uses request ID `0x710` and extended addressing with a target byte, so this is a concrete integration mismatch unless target-specific mapping exists. See [diagnostics](DIAGNOSTICS.md) and [compatibility](../compatibility/ZGW_FCD_GAP_ANALYSIS.md).

