# Diagnostics

## Application DCM

`ELC_APP/BSW/Diag/Dcm/Dcm.c` handles UDS in the application and uses a custom ISO-TP implementation. CAN RX is dispatched by `CanH`; the DCM configures STmin 5 ms and timeout 10,000 ms. It supports application-specific session, DIDs, reset, communication-control, DTC, and control routines. It is not the FBL service implementation.

## FBL UDS

Flash-resident `ELC_FBL/Core/Src/main.c:FBL_ProcessUds` only responds to `10 02` (programming session) while not programming; programming-state paths include `22 F1 7E/F1 7F/F1 80`, `31 01 0004` application erase, `31 01 0005` parameter erase, `34`, `36`, `37`, `31 01 0000` CRC check, `31 01 0007` RAM-updater entry, and `11 01` reset. There is no security-access (`27`) handler. Many unsupported/malformed requests are silently ignored rather than given a consistent NRC.

The RAM updater has a separate service parser: `10 02`, `34`, `36`, `37`, `31 01 0000` CRC, `31 01 0006` erase the entire FBL range, `11 01`, and version/state DIDs. It does not share session state/API with the resident parser.

## Important compatibility point

Neither FBL parser validates TransferData BSC progression or enforces received byte count equals RequestDownload size. The RAM parser validates download address range; the resident application parser does not visibly bound address/length in `34`. Treat protocol support as partial and do not equate accepted UDS services with standards-compliant flash programming.
