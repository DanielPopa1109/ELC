# Memory and build

## Linker map

`ELC_FBL/STM32F103C8TX_FLASH.ld`: FLASH `0x08000000`, length 14,336 (ends exclusive `0x08003800`); RAM `0x20000000`, length 20,416 (ends at `.ncr`); `.ncr` at `0x20004FC0`, 64 bytes. The FBL linker adds `.ram_blob`, with SRAM VMA and flash LMA, vectors first, then `.ram_blob_text*` and `.ram_blob_data*`; symbols expose load/VMA bounds.

`ELC_APP/STM32F103C8TX_FLASH.ld`: FLASH starts `0x08003C00`, length 48,125 (`0xBBFD`), whose last mapped byte is `0x0800F7FC`; RAM starts `0x20000000`, length 20,352; the same 64-byte `.ncr` reservation follows. FBL constants reserve parameter flash `0x08003800..0x08003BFF` (1 KiB), APP erase through `0x0800F7FF`, and CRC word at `0x0800F7FC`. **Potential one-byte overlap:** the linker FLASH region includes `0x0800F7FC`, the first byte of the FBL's four-byte CRC word. Inspect the actual APP map/HEX and correct the linker length or CRC location before release. These limits end at 64 KiB, consistent with the C8 linker map but conflict with the CMSIS compile define's B-density class; verify physical MCU/build artifacts.

## Persistent and runtime state

`.ncr` objects preserve software version/reset counters across software reset in SRAM; startup clears the 64-byte region on POR. This is reset-retained SRAM, not nonvolatile flash. APP `Nvm.c` separately stores DTC/freeze-frame/battery blocks and parameter data in flash using sector switching; inspect its exact layout before migration.

## Build

CubeIDE managed GNU make projects provide Debug/Release configurations; APP uses STM32Cube FW_F1 V1.8.5 and FreeRTOS CMSIS-RTOS v2. Generated `Debug/` and `Release/` trees are artifacts. No build was run for this documentation task. Ensure app image, FBL image and RAM blob fit linker regions and inspect map/HEX addresses as part of a future authorized build.
