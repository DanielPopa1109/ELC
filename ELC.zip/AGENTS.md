# ELC repository guidance

ELC is an STM32 ECU reference implementation. ZGW defines current gateway integration interfaces and FCD is the diagnostic/flashing reference tool; F93 supplies additional STM32 bootloader examples.

Before cross-project changes, inspect the target and the relevant ZGW/FCD/F93 source. Treat the knowledge bank under `docs/` as a map, then verify implementation and configuration because documentation, generated artifacts, and simulated target profiles can drift.

For firmware updates, start with [ELC FBL knowledge bank](docs/bootloader/INDEX.md), especially its distinct application writer and RAM self-updater. Separate gateway routing, ECU application behavior, MCU/hardware-specific flash/boot requirements, reusable protocol/state-machine ideas, and new development. Never copy MCU-specific flash, linker, vector or startup code blindly.

Update relevant docs when source, linker maps, diagnostic contracts, FCD target behavior or gateway routes change. Mark simulated/unverified behavior clearly; cite source paths/functions and exact configuration values. No behavior should be considered hardware validated solely from checked-in config, HEX, DBC, test scripts or docs.
